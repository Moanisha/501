﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Linqq
{
    class Example2
    {
        public static void Main()
        {
            List<employee> emp = new List<employee>()
            {
                new employee{employeeid=1,  empname="Raja",    city="chennai"},
                new employee{employeeid=2,  empname="Moanisha",city="bangalore"},
                new employee{employeeid=3,  empname="Rejit",   city="hyderabad"},
                new employee{employeeid=4,  empname="Ravi",    city="cochin"},
                new employee{employeeid=5,  empname="Deekshu", city="kolkata"},
                new employee{employeeid=6,  empname="Priyanka",city="pune"},
                new employee{employeeid=7,  empname="Asha",    city="coimbatore"},
                new employee{employeeid=8,  empname="Ashok",   city="madurai"},
                new employee{employeeid=9,  empname="Nithya",  city="chennai"},
                new employee{employeeid=10, empname="Surya",   city="coimbatore"},
                new employee{employeeid=11, empname="Madhi",   city="trivandrum"},
                new employee{employeeid=12, empname="Monikha", city="bangalore"}

            };
 //Display all employees name whose ids are less than 4
            //var output = from no in emp
            //              where no.employeeid<4
            //              select no;
            //foreach (var no in output)
            //{
            //    Console.WriteLine(no.empname);
            //}

            //var outl = emp.Where(c => c.employeeid < 4);
            //foreach (var no in outl)
            //{
            //    Console.WriteLine(no.empname);
            //}
//Display city name and no of employees working in the city
            //var output1=from no in emp
            //             group no by no.city into res
            //             select new { data = res.Key, total = res.Count() };
            //foreach (var i in output1)
            //Console.WriteLine("{0} city has {1} employees", i.data, i.total);

            //var outl1 = emp.GroupBy(c => c.city).Select(v => new { data = v.Key, total = v.Count() });
            //foreach (var i in outl1)
            //Console.WriteLine("{0} city has {1} employees", i.data, i.total);

//Display the cities and the employee names who are working in the city
            var output2=from no in emp
                        group no by no.city into res
                        select new { data = res.Key};
            foreach (var i in output2)
            {
                Console.WriteLine("\n"+i.data);
                var out3 = from no in emp
                           where no.city == i.data
                           select no.empname;
                         
                foreach(var o in out3)
                    Console.WriteLine("\t"+o);
            }
        }
    }

    class employee
    {
        public int employeeid{get;set;}
        public string empname { get; set; }
        public string city { get; set; }       
    }


}
