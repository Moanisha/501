﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Linqq
{
    class Program
    {
//        static void Main(string[] args)
//        {
//            int[] arr = {7, 1, 5, 3, 4, 2, 1, 6, 4, 8, 2, 9, 7 };

////Display all the elements in the array
//            //foreach (int no in arr)
//            //{
//            //    Console.WriteLine(no);
//            //}
////Linq concept
//            //IEnumerable<int> il = from no in arr  //IEnumerable  can be replaced with var
//            //                      select no;
//            //foreach (int no in il)
//            //{
//            //    Console.WriteLine(no);
//            //}
         
////Display the elements greater than 5
//            //foreach (int no in arr)
//            //{
//            //    if(no>5)
//            //        Console.WriteLine(no);
//            //}
////Linq Concept
//            //var output = from no in arr 
//            //                      where no >5
//            //                      select no;
//            //foreach (int no in output)
//            //{
//            //    Console.WriteLine(no);
//            //}
////Display all the elements in the array >5 which is distinct

//            //var output = (from no in arr
//            //             where no > 5
//            //              select no).Distinct(); 
//            //foreach (int no in output)
//            //{
//            //    Console.WriteLine(no);
//            //}

////Display all odd elements in the array which are greater than 5
//            //var output = (from no in arr
//            //              where no > 5 && no%2!=0
//            //              select no).Distinct(); ;
//            //foreach (int no in output)
//            //{
//            //    Console.WriteLine(no);
//            //}
////Lambda Expression
//            //var output = arr.Where(no => no > 5 && no % 2 != 0).Distinct();
//            //foreach (int no in output)
//            //{
//            //    Console.WriteLine(no);
//            //}
////Display all elements in array in descending order
//            //Array.Sort(arr);
//            //Array.Reverse(arr);
//            //foreach (int no in arr)
//            //{
//            //    Console.WriteLine(no);
//            //}
////Linq
//            //var output = from a in arr
//            //             orderby a descending
//            //             select a;
//            //foreach (int no in output)
//            //{
//            //    Console.WriteLine(no);
//            //}
////Lambda
//            //var output = arr.OrderByDescending(c=>c).Distinct();

//            //foreach (int no in output)
//            //{
//            //    Console.WriteLine(no);
//            //}
////Display how many no of unique elements in the array
//            //var output = arr.Distinct().Count();
//            //Console.WriteLine(output);

////Write a linq program that displays the average of elements greater than 5
//            //var output = (from no in arr 
//            //                      where no >5
//            //                      select no).Average();
            
//            //Console.WriteLine(output);
            
////Lambda                
//            //var output = arr.Where(no => no > 5).Average();
//            //Console.WriteLine(output);

//            string[] st = {"one","two","three","four","five","six","seven","eight","nine","ten" };

////Display all elements in the sorted order of length.. if same length starting letter alphabetic
//            //var output = (from no in st
//            //              orderby no.Length,no
//            //              select no);
//            //foreach (var no in output)
//            //{
//            //    Console.WriteLine(no);
//            //}
////Lambda
//            //var output = st.OrderBy(c => c.Length).ThenBy(c=>c) ;
//            //foreach (var no in output)
//            //{
//            //    Console.WriteLine(no);
//            //}

////Display all the elements in the array which have the letter o in it
//            //var output = (from letters in st
//            //              where letters.Contains("o")
//            //              select letters);
//            //foreach (var no in output)
//            //{
//            //    Console.WriteLine(no);
//            //}
////Lambda
//            //var output = st.Where(c => c.Contains("o"));
//            //foreach (var no in output)
//            //{
//            //    Console.WriteLine(no);
//            //}

////Display the highest 3 no in the int array
//            //Array.Sort(arr);
//            //var output = (from no in arr
//            //             orderby no descending
//            //             select no).Take(3) ;
//            //foreach (var no in output)
//            //{
//            //    Console.WriteLine(no);
//            //}
////Second and third highest element
//            //Array.Sort(arr);
//            //var output = (from no in arr
//            //              orderby no descending
//            //              select no).Skip(1).Take(2);
//            //foreach (var no in output)
//            //{
//            //    Console.WriteLine(no);
//            //}

//            //var output = arr.OrderByDescending(c => c).Distinct().Skip(1).Take(2);
//            //foreach (var no in output)
//            //{
//            //    Console.WriteLine(no);
//            //}
////Display the third highest element without using skip and take
//           // Array.Sort(arr);
//           // var output = (from no in arr
//           //               orderby no descending
//           //               select no).ElementAtOrDefault(2);
           
//           // Console.WriteLine(output);
//           //var output = arr.OrderByDescending(c => c).Distinct().ElementAtOrDefault(2);
//           //Console.WriteLine(output);

////Object arr
//            object[] ar = {1,1.1,"Moanisha",'J',true,25 };
////Get all double variables
//            //var res=ar.OfType<double>();
//            //foreach(var i in res)
//            //    Console.WriteLine(i);

////Repeated elements present how many times in an array
//            //var result = from s in arr
//            //             orderby s
//            //             group s by s into res
//            //             select new { data = res.Key, total = res.Count() };
//            //foreach(var i in result)
//            //    Console.WriteLine("{0} present {1} times",i.data,i.total);
////Display all the elements if its duplicate
//            //var result = from s in arr
//            //             orderby s
//            //             group s by s into res
//            //             where res.Count()>1
//            //             select new { data = res.Key, total = res.Count() };
//            //foreach (var i in result)
//            //    Console.WriteLine("{0} present {1} times", i.data, i.total);
////NOt duplicate
//            //var result = from s in arr
//            //             orderby s
//            //             group s by s into res
//            //             where res.Count() == 1
//            //             select new { data = res.Key, total = res.Count() };
//            //foreach (var i in result)
//            //    Console.WriteLine("{0} present {1} times", i.data, i.total);

//            var result = arr.OrderBy(s => s).GroupBy(s => s).Where(g => g.Count() > 1).Select(v => new { data = v.Key, total = v.Count() });
//            foreach (var i in result)
//                Console.WriteLine("{0} present {1} times", i.data, i.total);

//        }
    }
}
