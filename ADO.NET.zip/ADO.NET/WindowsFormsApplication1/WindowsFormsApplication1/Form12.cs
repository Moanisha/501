﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

//Display city and rent (output parameter) where property no is input from user

namespace WindowsFormsApplication1
{
    public partial class Form12 : Form
    {
        public Form12()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string constring = "server=Pc251449; database=Task1;integrated security=false; user id=sa; password=password-1";
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "pr3";
            
            SqlParameter sp1 = cmd.Parameters.Add("@prno", SqlDbType.VarChar, 20);
            sp1.Value = textBox1.Text;
            SqlParameter sp2 = cmd.Parameters.Add("@city", SqlDbType.VarChar, 20);
            sp2.Direction = ParameterDirection.Output;
            SqlParameter sp3 = cmd.Parameters.Add("@rent", SqlDbType.Decimal, 20);
            sp3.Direction = ParameterDirection.Output;

            cmd.ExecuteNonQuery();
            if (sp3.Value != DBNull.Value && sp2.Value != DBNull.Value)
            {
                textBox2.Text = sp2.Value.ToString();
                textBox3.Text = sp3.Value.ToString();
            }
            else
                MessageBox.Show("Property no is not valid");
       }
    }
}
