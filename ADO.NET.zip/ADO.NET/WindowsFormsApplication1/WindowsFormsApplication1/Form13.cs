﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

//Data Table
namespace WindowsFormsApplication1
{
    public partial class Form13 : Form
    {
        public Form13()
        {
            InitializeComponent();
        }

        private void Form13_Load(object sender, EventArgs e)
        {
            string[] arr = new string[]{" 1"," 2", "3"," 4" };
            DataTable dt = new DataTable();
            //dt.Columns.Add("S.NO", Type.GetType("System.String"));

            //foreach (string s in arr)
            //{
            //    dt.Rows.Add(s);
            //}
            ////dataGrid1.DataSource = dt;
            //DataSet ds = new DataSet();
            //ds.Tables.Add(dt);
            //dataGrid1.DataSource = ds.Tables[0];

            int[] arr1 = new int[] { 1, 2, 3, 4 };
            dt.Columns.Add("S.No int",Type.GetType("System.Int32"));
            foreach (int s in arr1)
            {
                dt.Rows.Add(s);
            }
            dataGrid1.DataSource = dt;
        }
    }
}
