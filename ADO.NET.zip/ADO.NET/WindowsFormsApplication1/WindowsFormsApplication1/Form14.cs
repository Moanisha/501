﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.Data.SqlClient;

//Populating different types of values in a datagrid

//Adding two columns in datatable
namespace WindowsFormsApplication1
{
    public partial class Form14 : Form
    {
        public Form14()
        {
            InitializeComponent();
        }

        private void Form14_Load(object sender, EventArgs e)
        {
            var info = new[]
            {
                new{id=1,name="Ram"},
                new{id=2,name="Arun"},     //Anonymous Types(Without declaring using it)
                new{id=2,name="Krish"}       
            };
            //ArrayList al = new ArrayList(info.ToList());
            //dataGrid1.DataSource = al;

            DataTable dt = new DataTable();
            dt.Columns.Add("Uid", Type.GetType("System.Int32"));
            dt.Columns.Add("Uname", Type.GetType("System.String"));
            UniqueConstraint uc = new UniqueConstraint("Uc1",dt.Columns[0]);
            dt.Constraints.Add(uc);
           
            foreach (var data in info)
            {
                DataRow dr = dt.NewRow();
                dr[0] = data.id;
                dr[1] = data.name;
                dt.Rows.Add(dr);
            }
            dataGrid1.DataSource = dt;
        }
    }
}
