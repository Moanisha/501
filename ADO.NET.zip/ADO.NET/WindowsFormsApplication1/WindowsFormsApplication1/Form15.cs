﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

//Insert and Save into database

namespace WindowsFormsApplication1
{
    public partial class Form15 : Form
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter da;
        DataSet ds;
        SqlCommandBuilder scb;
        public Form15()
        {
            InitializeComponent();
        }

        private void Form15_Load(object sender, EventArgs e)
        {
            display();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.BindingContext[ds, "branch"].Position++;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.BindingContext[ds, "branch"].Position--;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.BindingContext[ds, "branch"].Position = 0;
        }

        private void button4_Click(object sender, EventArgs e)
        {

            this.BindingContext[ds, "branch"].Position = this.BindingContext[ds, "branch"].Count - 1;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = false;
            button4.Enabled = false;
            button6.Enabled = true;
            textBox1.Enabled = true;
            textBox1.Text = "";
            textBox2.Enabled = true;
            textBox2.Text = "";
            textBox3.Enabled = true;
            textBox3.Text = "";
            textBox4.Enabled = true;
            textBox4.Text = "";

            string constring = "server=Pc251449; database=Task1;integrated security=false; user id=sa; password=password-1";
            string qry = "select max(branchno) from branch";
            con = new SqlConnection(constring);
            con.Open();
            cmd = new SqlCommand(qry, con);
            string data=(string)cmd.ExecuteScalar();  //Will retrieve first row first column.. Used only when one value is retrieved
            string bno;
                var input = data;
                var num = input.Substring(1, 3);
                int inc = int.Parse(num) + 1;
                if(inc<10)
                  bno = input.Substring(0,3) + inc.ToString();
                else if(inc<100)
                    bno = input.Substring(0,2) + inc.ToString();
                else
                    bno = input.Substring(0, 1) + inc.ToString();
                textBox1.Text = bno;
                textBox1.Enabled = false;
                

            
        }

        private void button6_Click(object sender, EventArgs e)
        {
            textBox1.Enabled = false;
            textBox2.Enabled = false;
            textBox3.Enabled = false;
            textBox4.Enabled = false;
            button1.Enabled = true;
            button2.Enabled = true;
            button3.Enabled = true;
            button4.Enabled = true;
            button5.Enabled = true;
            
            scb = new SqlCommandBuilder(da);
            DataRow dr = ds.Tables["branch"].NewRow();
            dr[0] = textBox1.Text;
            dr[1] = textBox2.Text;
            dr[2] = textBox3.Text;
            dr[3] = textBox4.Text;
            ds.Tables["branch"].Rows.Add(dr);
            da.Update(ds.Tables["branch"]);
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";

            MessageBox.Show("Records inserted successfully");
            textBox1.DataBindings.Clear();
            textBox2.DataBindings.Clear();
            textBox3.DataBindings.Clear();
            textBox4.DataBindings.Clear();
            display();
        }
        public void display()
        {
            button6.Enabled = false;
            string constring = "server=Pc251449; database=Task1; integrated security=false; user id=sa; password=password-1";
            string qry = "select * from branch";
            con = new SqlConnection(constring);
            con.Open();
            cmd = new SqlCommand(qry, con);
            da = new SqlDataAdapter(cmd);
            ds = new DataSet();
            da.Fill(ds, "branch");
            textBox1.DataBindings.Add("Text", ds, "branch.branchno");
            textBox2.DataBindings.Add("Text", ds, "branch.street");
            textBox3.DataBindings.Add("Text", ds, "branch.city");
            textBox4.DataBindings.Add("Text", ds, "branch.postcode");
            
        }
    }
}
