﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


//Delete from product table where product id is got from user
namespace WindowsFormsApplication1
{
    public partial class Form16 : Form
    {
        public Form16()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string constring = "server=Pc251449; database=chn17id001;integrated security=false; user id=sa; password=password-1";
            string qry = "delete from duplicate where prod_id=@pid";
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand cmd = new SqlCommand(qry, con);
            SqlParameter sp = cmd.Parameters.Add("@pid", SqlDbType.Int);
            sp.Value = textBox1.Text;
            int no = cmd.ExecuteNonQuery();
            if (no > 0)
                MessageBox.Show("Successfully Deleted");
            else
                MessageBox.Show("Product id not found");
            textBox1.Text = "";
        }
    }
}
