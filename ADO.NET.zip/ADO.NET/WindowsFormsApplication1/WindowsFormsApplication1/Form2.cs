﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


//Establish dataconnection using wizard
//Populate info in datagrid

namespace WindowsFormsApplication1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void dataGrid1_Navigate(object sender, NavigateEventArgs ne)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            sqlDataAdapter1.Fill(dataSet11);
            dataGrid1.DataSource = dataSet11;
        }
    }
}
