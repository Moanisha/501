﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


//Get the input from the user
//And display the other Details //Reset

namespace WindowsFormsApplication1
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox2.DataBindings.Clear();
            textBox3.DataBindings.Clear();
            textBox4.DataBindings.Clear();
            
            string constring = "server=Pc251449; database=Task1;integrated security=false; user id=sa; password=password-1";
            string qry = "select * from registration where clientno=@cno";
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = qry;
            SqlParameter sp = cmd.Parameters.Add("@cno",SqlDbType.VarChar,20);
            sp.Value = textBox1.Text;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds, "reg");
            if (ds.Tables[0].Rows.Count == 1)
            {
                textBox2.DataBindings.Add("Text", ds, "reg.branchno");
                textBox3.DataBindings.Add("Text", ds, "reg.staffno");
                textBox4.DataBindings.Add("Text", ds, "reg.datejoined");
                button1.Enabled = false;
            }
            else
                MessageBox.Show("No such client no is present");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            button1.Enabled = true;
        }
    }
}
