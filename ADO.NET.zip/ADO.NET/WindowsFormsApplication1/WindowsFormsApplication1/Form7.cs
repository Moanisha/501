﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


//Xml Schema
//Datagrid and RichTextBox


namespace WindowsFormsApplication1
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string constring="server=Pc251449; database=Task1;integrated security=false; user id=sa; password=password-1";
            string qry = "select * from staff";
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand cmd = new SqlCommand(qry, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds,"staff");
            dataGrid1.DataSource = ds;

            richTextBox1.Text = ds.GetXmlSchema();
            //richTextBox1.Text = ds.GetXml();

        }
    }
}
