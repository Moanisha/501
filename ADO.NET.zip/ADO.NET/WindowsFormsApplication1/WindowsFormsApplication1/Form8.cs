﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

//Display first row details on page load using Data Reader
//Next button click proceeds to other rows 

namespace WindowsFormsApplication1
{
    public partial class Form8 : Form
    { 
        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader dr;
        public Form8()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dr.Read())
            {
                textBox1.Text = dr[0].ToString();
                textBox2.Text = dr[1].ToString();
                textBox3.Text = dr[2].ToString();
                textBox4.Text = dr[3].ToString();
            }
            else
                MessageBox.Show("No records present in the table");
            }

        private void Form8_Load(object sender, EventArgs e)
        {
            string constring = "server=Pc251449; database=Task1;integrated security=false; user id=sa; password=password-1";
            string qry = "select * from staff";
            con = new SqlConnection(constring);
            con.Open();
            cmd = new SqlCommand(qry, con);
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                textBox1.Text = dr[0].ToString();
                textBox2.Text = dr[1].ToString();
                textBox3.Text = dr[2].ToString();
                textBox4.Text = dr[3].ToString();
            }
            else
                MessageBox.Show("No records present in the table");
           
        }
    }
}
