﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

//Populate the combo box using Datareader
//On selecting the value from combo box display the corresponding Details

namespace WindowsFormsApplication1
{
    public partial class Form9 : Form
    {
        public Form9()
        {
            InitializeComponent();
        }

        private void Form9_Load(object sender, EventArgs e)
        {
            string constring = "server=Pc251449; database=chn17id001;integrated security=false; user id=sa; password=password-1";
            string qry = "select distinct addres from customer";
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand cmd = new SqlCommand(qry, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                comboBox1.Items.Add(dr[0].ToString());
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            dataGrid1.Visible = true;
            string constr = "server=Pc251449; database=chn17id001;integrated security=false; user id=sa; password=password-1";
            string qry = "select * from customer where addres=@ad";
            SqlConnection cn = new SqlConnection(constr);
            cn.Open();
            SqlCommand cmd1 = cn.CreateCommand();
            cmd1.CommandType = CommandType.Text;
            cmd1.CommandText = qry;
            SqlParameter sp = cmd1.Parameters.Add("@ad", SqlDbType.VarChar, 20);
            sp.Value = comboBox1.Text;
            SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
            DataSet ds = new DataSet();
            da1.Fill(ds, "branch");
            dataGrid1.DataSource = ds.Tables["branch"];
        }
    }
}
