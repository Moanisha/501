﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using CarRegistration.DataAccess;


namespace CarRegistration.BusinessRules
{
    public class CarRegistrationBusinessRules
    {
    
        CarRegistrationDatalayer carRegister = new CarRegistrationDatalayer();
        
        /// <summary>
        /// To get the list of brand names from the data access layer
        /// </summary>
        /// <returns>The list of brand names of car available in the CarDetails Table as List(string)</returns>
        
        public List<string> PopulatingCarBrandName()
        {
            try
            {
                List<string> brandName = carRegister.PopulatingCarBrandName();
                return brandName;
            }
            catch (SqlException)
            {
                throw new Exception();
            }
            catch (IndexOutOfRangeException)
            {
                throw new Exception();
            }
            catch (NullReferenceException)
            {
                throw new Exception();
            }
            catch (Exception)
            {
                throw new Exception();
            }
            
        }
        
        /// <summary>
        /// To get the list of type of cars from the data access layer for the corresponding brandname(parameter)
        /// </summary>
        /// <param name="brandName">Brandname of car</param>
        /// <returns>The Type of cars available in the CarDetails Table for the selected brand name as List(string)</returns>
        
        public List<string> PopulatingCarTypeName(string brandName)
        {
            try
            {
                List<string> typeName = carRegister.PopulatingCarTypeName(brandName);
                return typeName;
            }
            catch (SqlException)
            {
                throw new Exception();
            }
            catch (IndexOutOfRangeException)
            {
                throw new Exception();
            }
            catch (NullReferenceException)
            {
                throw new Exception();
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        /// <summary>
        /// It will pass the entered customer rental details to the dataaccess layer to insert into CustomerRegistrationDetails table
        /// </summary>
        /// <param name="detail">Contains all the fields of CustomerRegistrationDetails table</param>
        /// <returns>Success or Error message(string)</returns>
        
        public string InsertingCustomerRentalDetails(CustomerRentalDetails customerDetail)
        {
            try
            {
               string result = carRegister.InsertingCustomerRentalDetails(customerDetail);
               return result;
            }
            catch (SqlException)
            {
                throw new Exception();
            }
            catch (NullReferenceException)
            {
                throw new Exception();
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

    }
}
