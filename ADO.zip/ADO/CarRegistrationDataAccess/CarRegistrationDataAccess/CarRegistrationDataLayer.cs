﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Web;
using System.Configuration;

namespace CarRegistration.DataAccess
{
  
    public class CarRegistrationDatalayer
    {   
        string ConnectionString = ConfigurationManager.ConnectionStrings["CarRegistrationConnection"].ConnectionString;
        SqlConnection carRegistrationConnection;
        SqlCommand carRegistrationCommandObject;
       
        /// <summary>
        /// Constructor to establish connection with the CarRegistrationDatabase
        /// </summary>
        /// 
        public CarRegistrationDatalayer()
        {
            carRegistrationConnection = new SqlConnection(ConnectionString);
            
        }

        /// <summary>
        /// To insert customer Rental details into CustomerRegistrationDetails Table
        /// </summary>
        /// <param name="detail">Contains all the fields of CustomerRegistrationDetails table</param>
        /// <returns>Success or Error Message(string)</returns>
        /// 
        public string InsertingCustomerRentalDetails(CustomerRentalDetails customerRentalDetails)
        {
            try
            {
                carRegistrationConnection.Open();
                carRegistrationCommandObject = carRegistrationConnection.CreateCommand();
                carRegistrationCommandObject.CommandType = CommandType.StoredProcedure;
                carRegistrationCommandObject.CommandText = "USP_InsertCustomerDetails";
                carRegistrationCommandObject.Parameters.AddWithValue("@CustomerName", customerRentalDetails.CustomerName);
                carRegistrationCommandObject.Parameters.AddWithValue("@EmailId", customerRentalDetails.EmailId);
                carRegistrationCommandObject.Parameters.AddWithValue("@PhoneNumber", customerRentalDetails.PhoneNumber);
                carRegistrationCommandObject.Parameters.AddWithValue("@CarBrand", customerRentalDetails.CarBrand);
                carRegistrationCommandObject.Parameters.AddWithValue("@CarType", customerRentalDetails.CarType);
                carRegistrationCommandObject.Parameters.AddWithValue("@CarPrice", customerRentalDetails.CarPrice);
                SqlParameter SuccessResult = carRegistrationCommandObject.Parameters.Add("@SuccessResult", SqlDbType.VarChar, 20);
                SuccessResult.Direction = ParameterDirection.Output;
                carRegistrationCommandObject.ExecuteNonQuery();
                string returnValue = (string)carRegistrationCommandObject.Parameters["@SuccessResult"].Value;
                carRegistrationConnection.Close();
                return returnValue;
            }
            catch (SqlException)
            {
                throw new Exception();
            }
            catch (NullReferenceException)
            {
                throw new Exception();
            }
            catch (Exception)
            {
                throw new Exception();
            } 
            finally
            {
                carRegistrationConnection.Close();
            }
        }

        /// <summary>
        /// To get the available brand names from the CarDetails table 
        /// </summary>
        /// <returns>The list of brand names of car available in the CarDetails Table as List(string)</returns>

        public List<string> PopulatingCarBrandName()
        {
            try
            {
                carRegistrationConnection.Open();
                carRegistrationCommandObject = carRegistrationConnection.CreateCommand();
                carRegistrationCommandObject.CommandType = CommandType.StoredProcedure;
                carRegistrationCommandObject.CommandText = "USP_PopulatingCarBrandNames";
                SqlDataReader CarBrandDataRead =carRegistrationCommandObject.ExecuteReader();

                List<string> carBrandNames = new List<string>();
                while (CarBrandDataRead.Read())
                {
                    carBrandNames.Add(CarBrandDataRead[0].ToString());
                }
                carRegistrationConnection.Close();
                return carBrandNames;
            }
            catch (SqlException)
            {
                throw new Exception();
            }
            catch (IndexOutOfRangeException)
            {
                throw new Exception();
            }
            catch (NullReferenceException)
            {
                throw new Exception();
            }
            catch(Exception)
            {
                throw new Exception();
                }
            finally
            {
                carRegistrationConnection.Close();
            }
         }
    
        /// <summary>
        /// To get the available type of cars for the selected brand name from CarDetails table
        /// </summary>
        /// <param name="carBrand">Contains the Brand of the car</param>
        /// <returns>The Type of cars available in the CarDetails Table for the selected brand name as List(string)</returns>

        public List<string> PopulatingCarTypeName(string carBrand)
        {
            try
            {
                carRegistrationConnection.Open();
                carRegistrationCommandObject = carRegistrationConnection.CreateCommand();
                carRegistrationCommandObject.CommandType = CommandType.StoredProcedure;
                carRegistrationCommandObject.CommandText = "USP_PopulatingCarTypeNames";
                carRegistrationCommandObject.Parameters.AddWithValue("@CarBrand", carBrand);
                SqlDataReader CarTypeDataRead = carRegistrationCommandObject.ExecuteReader();

                List<string> carTypeNames = new List<string>();
                while (CarTypeDataRead.Read())
                {
                    carTypeNames.Add(CarTypeDataRead[0].ToString());
                }
                carRegistrationConnection.Close();
                return carTypeNames;
            }
            catch (SqlException)
            {
                throw new Exception();
            }
            catch (IndexOutOfRangeException)
            {
                throw new Exception();
            }
            catch (NullReferenceException)
            {
                throw new Exception();
            }
            catch (Exception)
            {
                throw new Exception();
            }
            finally
            {
                carRegistrationConnection.Close();
            }
        }

    }
}

