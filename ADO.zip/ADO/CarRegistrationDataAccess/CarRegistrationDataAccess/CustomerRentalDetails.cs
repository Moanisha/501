﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarRegistration.DataAccess
{  
    /// <summary>
    /// Model class for CustomerRegistrationDetails Table to access object data in all layers    
    /// </summary>
  
    public class CustomerRentalDetails
    {
        public string CustomerName { get; set; }
        public string EmailId { get; set; }
        public long PhoneNumber { get; set; }
        public string CarBrand { get; set; }
        public string CarType { get; set; }
        public string CarPrice { get; set; }

    }
}
