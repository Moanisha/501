﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Data;
using System.Data.SqlClient;
using CarRegistration.DataAccess;
using CarRegistration.BusinessRules;


namespace carRegistrationForm.Controllers
{
    public class CarRegistrationApiController : ApiController
    {
        CarRegistrationBusinessRules carRegister = new CarRegistrationBusinessRules();
       
        /// <summary>
        /// To get the list of brand names available from the business logic
        /// </summary>
        /// <returns>The list of brand names of car available in the CarDetails Table as List(string)</returns>
        
        [HttpGet]
        public List<string> PopulatingCarBrandName()
        {
            try
            {
                List<string> brandName = carRegister.PopulatingCarBrandName();
                return brandName;
            }
            catch (SqlException)
            {
                return new List<string>() { "EXCEPTION" };
            }
            catch (IndexOutOfRangeException)
            {
                return new List<string>() { "EXCEPTION" };
            }
            catch (NullReferenceException)
            {
                return new List<string>() { "EXCEPTION" };
            }
            catch (Exception)
            {
                return new List<string>() { "EXCEPTION" };
               
            }
        }
        
        /// <summary>
        /// To get the type of cars for a corresponding brandname(parameter) from business logic
        /// </summary>
        /// <param name="brandListValue">Brandname of car</param>
        /// <returns>The Type of cars available in the CarDetails Table for the selected brand name as List(string)</returns>
       
        [HttpGet]
        public List<string> PopulatingCarTypeName(string brandName)
        {
            try
            {
                List<string> brandType = carRegister.PopulatingCarTypeName(brandName);
                return brandType;
            }
            catch (SqlException)
            {
                return new List<string>() { "EXCEPTION" };
            }
            catch (IndexOutOfRangeException)
            {
                return new List<string>() { "EXCEPTION" };
            }
            catch (NullReferenceException)
            {
                return new List<string>() { "EXCEPTION" };
            }
            catch (Exception)
            {
                return new List<string>() { "EXCEPTION" };
            }
        }
      
        /// <summary>
        /// Save the customer details into the CustomerRegistrationDetails table
        /// </summary>
        /// <param name="detail">Contails all the fields of CustomerRegistrationDetails table</param>
        /// <returns>Status message(string)</returns>
       
        [HttpPost]
        public string InsertingCustomerRentalDetails(CustomerRentalDetails customerRentalDetails)
        {
            try
            {
                string insertResult = carRegister.InsertingCustomerRentalDetails(customerRentalDetails);
                return insertResult;
            }
            catch (SqlException)
            {
                return "EXCEPTION";
            }
            catch (NullReferenceException)
            {
                return "EXCEPTION";
            }
            catch (Exception)
            {
                return "EXCEPTION";

            }
        }
    }
}
