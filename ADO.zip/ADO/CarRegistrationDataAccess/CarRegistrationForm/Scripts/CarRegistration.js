﻿
//Car Registration Form Validation and Ajax Calling Webservice to retrieve data from database and to insert data 

$(document).ready(function () {
//Calling a webservice using ajax to get the value for brandname dropdownlist
    $.ajax({
        url: "/api/CarRegistrationApi/PopulatingCarBrandName",
        type: "GET",
        dataType: "json",
        contentType: "application/json;charset=UTF-8",
        success: function (data) {
            if (data[0] == "EXCEPTION") {
                alert(data[0] + "Occured...Please Try Again")
                $("#sendDetails").css({
                    "display": "none"
                })
            }
            else
            {
                $.each(data, function (key, val) {
                    $("#brandList").append("<option class='dropdown-content'>" + val + "</option>");
                  
                })
            }
        },
        error: function (xhr) {
            alert("ERROR:" + xhr);
        },
        statusCode:
            {
                404: function () {
                    alert("PAGE NOT FOUND");
                }
            }
    });

   


//Calling a webservice using ajax to get the value for type of car dropdownlist for corresponding brand name data
    $("#brandList").change(function () {
        var res = $(this).val();
        $.ajax({
            url: "/api/CarRegistrationApi/PopulatingCarTypeName",
            type: "GET",
            dataType: "json",
            data: { 'brandName': res },
            contentType: "application/json;charset=UTF-8",
            success: function (data) {
                if (data[0] == "EXCEPTION") {
                    alert(data[0] + "Occured...Please Try Again")
                    $("#sendDetails").css({
                        "display": "none"
                    })
                }
                else {
                    $("#typeList").empty();
                    $("#typeList").append("<option>TYPE OF CAR</option>");
                    $.each(data, function (key, val) {
                        $("#typeList").append("<option>" + val + "</option>");
                    })
                }
            },
            error: function (xhr) {
                alert("ERROR:" + xhr);
            },
            statusCode:
                {
                    404: function () {
                        alert("PAGE NOT FOUND");
                    }
                }
        });

    });

    
    var nameRegex = new RegExp("^[a-zA-Z][a-zA-Z ]+$");
    var emailRegex = new RegExp("^[a-zA-Z+-]+[a-zA-Z0-9.]+@[a-zA-Z]+\.[A-Za-z]{2,6}$");
    var phoneRegex = new RegExp("^[0-9]{10}$");


    $("#fullNametxt").blur(function () {

        if (!nameRegex.test($("#fullNametxt").val()) & $("#fullNametxt").val() != "") {
            $.toaster({ priority: 'danger', title: 'Alert ', message: 'Name not valid' });
        }
    });
    $("#Emailtxt").blur(function () {
        if (!emailRegex.test($("#Emailtxt").val()) & $("#Emailtxt").val() != "") {
            $.toaster({ priority: 'danger', title: 'Alert ', message: 'Email ID not valid' });
        }
    });
    $("#phonetxt").blur(function () {
        if (!phoneRegex.test($("#phonetxt").val()) & $("#phonetxt").val() != "") {
            $.toaster({ priority: 'danger', title: 'Alert ', message: 'Phone Number not valid' });
        }
    });

//Send button click validation functions using Toasters
    $("#sendDetails").click(function () {
        
//Name textbox empty validation check
        if ($("#fullNametxt").val() === "") {
            $.toaster({ priority: 'danger', title: 'Alert : ', message: 'Please Enter your Name' });
        }

//Email textbox empty validation check
        else if ($("#Emailtxt").val() === "") {

            $.toaster({ priority: 'danger', title: 'Alert : ', message: 'Please Enter Email ID' });
        }

//Phone number textbox empty validation check
        else if ($("#phonetxt").val() === "") {

            $.toaster({ priority: 'danger', title: 'Alert : ', message: 'Please Enter Phone no' });
        }

//Check if Brandname dropdownlist is selected
        else if ($("#brandList").val() === "SELECT BRAND") {

            $.toaster({ priority: 'danger', title: 'Alert : ', message: 'Please choose Brand of Car' });
        }

//Check if Type of car dropdownlist is selected
        else if ($("#typeList").val() === "TYPE OF CAR") {

            $.toaster({ priority: 'danger', title: 'Alert : ', message: 'Please choose Type of Car' });
        }

//Check if Price Range radio button is selected
        else if (!$("input[name=price]:checked").val()) {

            $.toaster({ priority: 'danger', title: 'Alert : ', message: 'Please select Price Range' });
        }


//Sending all the form field values to webservice 
        else {

            var registerDetails = {};
            registerDetails.customerName = $("#fullNametxt").val();
            registerDetails.emailId = $("#Emailtxt").val();
            registerDetails.phoneNumber = $("#phonetxt").val();
            registerDetails.carBrand = $("#brandList").val();
            registerDetails.carType = $("#typeList").val();
            registerDetails.carPrice = $("input[name=price]:checked").val();
            var res = JSON.stringify(registerDetails);
            $.ajax({
                url: "/api/CarRegistrationApi/InsertingCustomerRentalDetails",
                type: "POST",
                dataType: "json",
                data: res,
                contentType: "application/json;charset=UTF-8",
                success: function (data) {
                                     if (data == "SUCCESS") {
                        $.toaster({ priority: 'success', title: 'Alert:', message: data });
                        setTimeout(function () {
                            window.location.reload();
                        }, 2500);
                    }
                    else if (data == "ERROR") {
                        $.toaster({ priority: 'danger', title: 'Alert:', message: data });
                        setTimeout(function () {
                            window.location.reload();
                        }, 2500);
                    }
                    
                    else {
                        alert(data + "Occured...Please Try Again")
                            setTimeout(function () {
                            window.location.reload();
                            }, 1500);
                            $("#sendDetails").css({
                                "display": "none"
                            })
                    }
                    },

                error: function (xhr) {
                    $.toaster({ priority: 'danger', title: 'Alert : ', message: 'Error occured' });
                },

            });
        }
        });
    
    });
    
