﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace First_Application
{
    class Armstrong
    {
        //public static void Main()
        //{
        //    int num, rem, tmp,sum=0;
        //    Console.WriteLine("Enter the Number");
        //    num = int.Parse(Console.ReadLine());
        //    tmp = num;
        //    while (num != 0)
        //    {
        //        rem = num % 10;
        //        sum = sum + rem * rem * rem;
        //        num = num / 10;
        //    }
        //    if (sum == tmp)
        //        Console.WriteLine("{0} is Armstrong Number",tmp);
        //    else
        //        Console.WriteLine("{0} is not an Armstrong Number", tmp);
        //}
    }
}
