﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace First_Application
{
    class Case_sensitive
    {
        //public static void Main()
        //{
        //    char a;
        //    Console.WriteLine("Enter the character");
        //    a = char.Parse(Console.ReadLine());
        //    if (char.IsLower(a))
        //        Console.WriteLine("The character is in Lower Case");
        //    else if(char.IsUpper(a))
        //        Console.WriteLine("The character is in Upper Case");
        //    else
        //        Console.WriteLine("Invalid Data");
        //}
    }
}
