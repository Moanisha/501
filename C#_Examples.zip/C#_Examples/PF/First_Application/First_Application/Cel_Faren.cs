﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace First_Application
{
    class Cel_Faren
    {
        //public static void Main()
        //{
        //    double cel, faren;
        //    Console.WriteLine("Enter the Celsius Value");
        //    cel = double.Parse(Console.ReadLine());
        //    faren = (cel * 9) / 5 + 32;
        //    Console.WriteLine("Farenheit value of {0} degree celsius is {1}", cel, faren); 
        //}
    }
}
