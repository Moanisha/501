﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace First_Application
{
    class Class
    {
        //public static void Main()
        //{
        //    int a, b, c;
        //    //a = 10;
        //    //b = 20;
        //    a = int.Parse(Console.ReadLine());
        //    b = int.Parse(Console.ReadLine());
        //    c = a + b;
        //    Console.WriteLine("Total of {0} and {1} is {2}", a, b, c);
        //    Console.WriteLine("The total is:" +c);
        //    Console.WriteLine("New Class");
        //}
    }
}
