﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace First_Application
{
    class Days
    {
        //public static void Main()
        //{
        //    int day,yr,wk,a;
        //    Console.WriteLine("Enter the Number of Days");
        //    day = int.Parse(Console.ReadLine());
        //    a = day;
        //    yr = day / 365;
        //    day = day % 365;
        //    wk = day / 7;
        //    day = day % 7;
        //    Console.WriteLine("{0} Days is equal to {1} Years,{2} Weeks, {3} Days", a, yr, wk, day);
        //}
    }
}
