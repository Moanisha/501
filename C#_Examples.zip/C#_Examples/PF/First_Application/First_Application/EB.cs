﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace First_Application
{
    class EB
    {
        //public static void Main()
        //{
        //    double ebill=0,eb1=0,eb2=0,eb3=0,eb4=0;
        //    int unit, t1,t2,t3;
        //    Console.WriteLine("Enter the number of Units");
        //    unit = int.Parse(Console.ReadLine());
        //    if (unit <= 50)
        //    {
        //        ebill = unit * 0.5;
        //        ebill = ebill + (ebill * 0.2);
        //        Console.WriteLine("Electricity Bill for {0} units : {1}", unit, ebill);
        //    }
        //    else if (unit > 50 & unit <=250)
        //    {
        //        t1 = unit - 50;
        //        eb1 = 50 * 0.5;
        //        if (t1 >= 100)
        //        {
        //            eb2 = 100 * 0.75;
        //            t2 = t1 - 100;
        //            eb3 = t2 * 1.20;
        //        }
        //        else
        //        {
        //            eb2 = t1 * 0.75;
        //        }
        //        ebill = eb1 + eb2 + eb3;
        //        ebill = ebill + (ebill * 0.2);
        //        Console.WriteLine("Electricity Bill for {0} units : {1}", unit, ebill);
        //    }
        //    else if (unit > 250)
        //    {
        //        t1 = unit - 50;
        //        eb1 = 50 * 0.5;
        //        t2 = t1 - 100;
        //        eb2 = 100 * 0.75;
        //        t3 = t2 - 100;
        //        eb3 = 100 * 1.2;
        //        eb4 = t3 * 1.5;
        //        ebill = eb1 + eb2 + eb3 + eb4;
        //        ebill = ebill + (ebill * 0.2);
        //        Console.WriteLine("Electricity Bill for {0} units : {1}", unit, ebill);
        //    }
        //}
    }
}
