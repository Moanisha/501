﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace First_Application
{
    class Factorial
    {
        //public static void Main()
        //{
        //    int num,fct,i;
        //    Console.WriteLine("Enter the Number");
        //    num = int.Parse(Console.ReadLine());
        //    if (num == 0)
        //    {
        //         fct = 1;
        //    }
        //    else
        //    {
        //        fct = 1;
        //        for (i = 1; i <= num; i++)
        //        {
        //            fct = fct * i;
        //        }
        //    }
        //    Console.WriteLine("Factorial of {0} is {1}", num, fct);
        //}
    }
}
