﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace First_Application
{
    class Faren_Cel
    {
        //public static void Main()
        //{
        //    double cel, faren;
        //    Console.WriteLine("Enter the Farenheit Value");
        //    faren = double.Parse(Console.ReadLine());
        //    cel = (faren - 32) * 5 / 9;
        //    Console.WriteLine("Celsius value of {0} degree farenheit is {1}", faren, cel);
        //}
    }
}
