﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace First_Application
{
    class Generic
    {
        //public static void Main()
        //{
        //    int num, sum, r, a;
        //    sum = 0;
        //    Console.WriteLine("Enter the number:");
        //    num = int.Parse(Console.ReadLine());
        //    a = num;
        //    while (num >= 10)
        //    {
        //        sum = 0;
        //        while (num != 0)
        //        {
        //            r = num % 10;
        //            num = num / 10;
        //            sum = sum + r;
        //        }
        //        num = sum;
        //    }
        //    Console.WriteLine("Sum of digits {0} is {1}", a, sum);
        //}
    }
}
