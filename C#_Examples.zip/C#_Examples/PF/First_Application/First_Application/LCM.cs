﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace First_Application
{
    class LCM
    {
        public static void Main(string[] args)
        {
            int n1, n2, a, b, lcm = 0;
            Console.WriteLine("Enter the First Number : ");
            n1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the Second Number : ");
            n2 = int.Parse(Console.ReadLine());
            a = n1;
            b = n2;
            while (n1 != n2)
            { 
                if (n1 > n2)
                {
                    n1 = n1 - n2;
                }
                else
                {
                    n2 = n2 - n1;
                }
            }
            lcm = (a * b) / n1;
            Console.Write("Lcm of {0},{1} : {2}",n1,n2,lcm);
            Console.WriteLine("Thanks");
        }
    }
}
