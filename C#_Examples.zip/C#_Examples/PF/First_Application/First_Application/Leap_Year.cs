﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace First_Application
{
    class Leap_Year
    {
        //public static void Main()
        //{
        //    int yr;
        //    Console.WriteLine("Enter the Year");
        //    yr = int.Parse(Console.ReadLine());
        //    if (yr % 400 == 0)
        //        Console.WriteLine("{0} is Leap Year", yr);
        //    else if(yr % 100 ==0)
        //        Console.WriteLine("{0} is not Leap Year", yr);
        //    else if(yr % 4 ==0)
        //        Console.WriteLine("{0} is Leap Year", yr);
        //    else
        //        Console.WriteLine("{0} is not Leap Year", yr);
        //}
    }
}
