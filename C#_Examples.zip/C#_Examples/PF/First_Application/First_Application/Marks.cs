﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace First_Application
{
    class Marks
    {
        //public static void Main()
        //{
        //    int i,sum=0;
        //    double per;
        //    int[] m = new int[5];
        //    Console.WriteLine("Enter the Marks: Physics,Chemistry,Biology,Maths,Computer");
        //    for (i = 0; i < 5; i++)
        //    {
        //        m[i] = int.Parse(Console.ReadLine());
        //    }
        //    foreach (int item in m)
        //    {
        //        sum = sum + item;
        //    }
        //    per = sum / 5;
        //    Console.WriteLine("The percentage of marks is {0}", per);
        //    if(per >= 90)
        //        Console.WriteLine("A Grade");
        //    else if(per>=80)
        //        Console.WriteLine("B Grade");
        //    else if (per >= 70)
        //        Console.WriteLine("C Grade");
        //    else if (per >= 60)
        //        Console.WriteLine("D Grade");
        //    else if (per >= 40)
        //        Console.WriteLine("E Grade");
        //    else if (per < 40)
        //        Console.WriteLine("F Grade");
        //    else
        //        Console.WriteLine("Invalid");
        //}
    }
}
