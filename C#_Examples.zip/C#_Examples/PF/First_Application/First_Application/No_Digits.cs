﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace First_Application
{
    class No_Digits
    {
        //public static void Main()
        //{
        //    int num,count=0;
        //    Console.WriteLine("Enter the Number");
        //    num = int.Parse(Console.ReadLine());
        //    while (num != 0)
        //    {
        //        num = num / 10;
        //        count++;
        //    }
        //    Console.WriteLine("No of Digits: {0}", count);
        //}
    }
}
