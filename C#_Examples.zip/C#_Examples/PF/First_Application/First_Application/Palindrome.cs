﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace First_Application
{
    class Palindrome
    {
        //public static void Main()
        //{
        //    int num, rev, a;
        //    rev = 0;
        //    Console.WriteLine("Enter the Number:");
        //    num = int.Parse(Console.ReadLine());
        //    a = num;
        //    while (num != 0)
        //    {
        //        rev = rev * 10;
        //        rev = rev + num % 10;
        //        num = num / 10;
        //    }
        //    if (rev == a)
        //        Console.WriteLine("{0} is Palindrome", a);
        //    else
        //        Console.WriteLine("{0} is not Palindrome", a);         
        //}
    }
}
