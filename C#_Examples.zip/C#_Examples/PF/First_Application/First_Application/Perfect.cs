﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace First_Application
{
    class Perfect
    {
        //public static void Main()
        //{
        //    int num, i, s = 0;
        //    Console.WriteLine("Enter the number");
        //    num = int.Parse(Console.ReadLine());
        //    if (num > 0)
        //    {
        //        for (i = 1; i < num; i++)
        //        {
        //            if (num % i == 0)
        //            {
        //                s = s + i;
        //            }
        //        }
        //        if (s == num)
        //            Console.WriteLine("{0} is Perfect number", num);
        //        else
        //            Console.WriteLine("{0} is not Perfect number", num);
        //    }
        //}
    }
}
