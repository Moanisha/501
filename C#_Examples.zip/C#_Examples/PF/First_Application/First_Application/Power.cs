﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace First_Application
{
    class Power
    {
        //public static void Main()
        //{
        //    int num, pow;
        //    double a;
        //    Console.WriteLine("Enter the Number:");
        //    num = int.Parse(Console.ReadLine());
        //    Console.WriteLine("Enter the Power:");
        //    pow = int.Parse(Console.ReadLine());
        //    a = Math.Pow(num, pow);
        //    Console.WriteLine("{0} power {1} is {2}", num, pow, a);
        //}
    }
}
