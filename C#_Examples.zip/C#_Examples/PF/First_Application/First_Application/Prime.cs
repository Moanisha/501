﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace First_Application
{
    class Prime
    {
        //public static void Main()
        //{
        //    int num, i, k;
        //    Console.WriteLine("Enter the Number");
        //    num = int.Parse(Console.ReadLine());
        //    k = 0;
        //    for (i = 1; i <= num; i++)
        //    {
        //        if (num % i == 0)
        //        {
        //            k++;
        //        }
        //    }
        //    if (k == 2)
        //        Console.WriteLine("The number is Prime");
        //    else
        //        Console.WriteLine("The number is not Prime");
        //}
    }
}
