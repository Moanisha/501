﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace First_Application
{
    class Program
    {
        //static void Main(string[] args)
        //{
        //    Console.WriteLine("My first example");
        //    Console.ReadLine();
        //}
    }
}
