﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace First_Application
{
    class Reverse
    {
        //public static void Main()
        //{
        //    int num, rev, a;
        //    rev = 0;
        //    Console.WriteLine("Enter the Number:");
        //    num = int.Parse(Console.ReadLine());
        //    a = num;
        //    while (num != 0)
        //    {
        //        rev = rev * 10;
        //        rev = rev + num % 10;
        //        num = num / 10;
        //    }
        //    Console.WriteLine("Reverse of {0} is {1}", a, rev);
        //}
    }
}
