﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace First_Application
{
    class Salary
    {
        //public static void Main()
        //{
        //    double sal,hra,da;
        //    Console.WriteLine("Enter the Salary");
        //    sal = double.Parse(Console.ReadLine());
        //    if (sal >= 10000)
        //    {
        //        hra = (sal * 20) / 100;
        //        da = (sal * 80) / 100;
        //        Console.WriteLine("Salary: {0} HRA :{1} DA:{2}",sal,hra,da);
        //    }
        //    else if (sal >= 20000)
        //    {
        //        hra = (sal * 25) / 100;
        //        da = (sal * 90) / 100;
        //        Console.WriteLine("Salary: {0} HRA :{1} DA:{2}", sal, hra, da);
        //    }
        //    else if (sal >= 30000)
        //    {
        //        hra = (sal * 30) / 100;
        //        da = (sal * 95) / 100;
        //        Console.WriteLine("Salary: {0} HRA :{1} DA:{2}", sal, hra, da);
        //    }
        //    else
        //        Console.WriteLine("Enter the correct salary value");
        //}
    }
}
