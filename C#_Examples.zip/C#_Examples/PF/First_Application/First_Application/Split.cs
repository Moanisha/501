﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace First_Application
{
    class Split
    {
        //public static void Main()
        //{
        //    int num, i = 0, n;
        //    int[] r = new int[10];
        //    Console.WriteLine("Enter the Number");
        //    num = int.Parse(Console.ReadLine());
        //    while (num != 0)
        //    {
        //        r[i] = num % 10;
        //        i++;
        //        num = num / 10;
        //    }
        //    for (n = i-1; n >= 0; n--)
        //    {
        //        Console.Write("{0} ", r[n]);
        //    }
        //}
    }
}
