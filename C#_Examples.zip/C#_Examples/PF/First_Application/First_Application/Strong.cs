﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace First_Application
{
    class Strong
    {
        //public static void Main()
        //{
        //    int num,rem,fct=1,i,sum=0,tmp;
        //    Console.WriteLine("Enter the Number");
        //    num = int.Parse(Console.ReadLine());
        //    tmp = num;
        //    while (num != 0)
        //    {
        //        rem = num % 10;
        //        if (rem == 0)
        //        {
        //            fct = 1;
        //        }
        //        else
        //        {
        //            fct = 1;
        //            for (i = 1; i <= rem; i++)
        //            {
        //                fct = fct * i;
        //            }
        //        }
        //        sum = sum + fct;
        //        num = num / 10;
        //    }
        //    if (sum == tmp)
        //        Console.WriteLine("{0} is strong",num);
        //    else
        //        Console.WriteLine("{0} is not strong",num);  
        //}
    }
}
