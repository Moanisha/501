﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace First_Application
{
    class Tables
    {
        //public static void Main()
        //{
        //    int n, i,a;
        //    Console.WriteLine("Enter the Table Number");
        //    n = int.Parse(Console.ReadLine());
        //    for (i = 1; i < 11; i++)
        //    {
        //        a = n * i;
        //        Console.WriteLine("{0} * {1} = {2}", n, i,a);
        //    }
        //}
    }
}
