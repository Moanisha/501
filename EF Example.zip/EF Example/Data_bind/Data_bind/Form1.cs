﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Data_bind
{
    public partial class Form1 : Form
    {
        chn17id001Entities ce;
            
        public Form1()
        {
            InitializeComponent();
            ce = new chn17id001Entities();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            var info = ce.products;
            MessageBox.Show(info.ToString());
            int total = ce.products.Count();
            if (total > 0)
            {
                //var res = ce.products.OrderBy(x => x.prod_id).FirstOrDefault();
                var res = (from s in ce.products
                           orderby s.prod_id
                           select s).FirstOrDefault();
                textBox1.Text = res.prod_id.ToString();
                textBox2.Text = res.prod_name.ToString();
                textBox3.Text = res.mfg_date.ToString();
                textBox4.Text = res.exp_date.ToString();
                textBox5.Text = res.price.ToString();
                textBox6.Text = res.company.ToString();
            }
            else
                MessageBox.Show("Records not found");
       }

        private void button1_Click(object sender, EventArgs e)
        {

            int total = ce.products.Count();
            if (total > 0)
            {
                //var res = ce.products.OrderBy(x => x.prod_id).FirstOrDefault();
                var res = (from s in ce.products
                           orderby s.prod_id
                           select s).FirstOrDefault();
                textBox1.Text = res.prod_id.ToString();
                textBox2.Text = res.prod_name.ToString();
                textBox3.Text = res.mfg_date.ToString();
                textBox4.Text = res.exp_date.ToString();
                textBox5.Text = res.price.ToString();
                textBox6.Text = res.company.ToString();
            }
            else
            {
                MessageBox.Show("Records not found");
               
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int total = ce.products.Count();
            if (total > 0)
            {
                //var res = ce.products.OrderBy(x => x.prod_id).FirstOrDefault();
                var res = (from s in ce.products
                           orderby s.prod_id descending
                           select s).FirstOrDefault();
                textBox1.Text = res.prod_id.ToString();
                textBox2.Text = res.prod_name.ToString();
                textBox3.Text = res.mfg_date.ToString();
                textBox4.Text = res.exp_date.ToString();
                textBox5.Text = res.price.ToString();
                textBox6.Text = res.company.ToString();
            }
            else
            {
                MessageBox.Show("Records not found");
             
            }
         }

        private void button3_Click(object sender, EventArgs e)
        {
            int val = Int32.Parse(textBox1.Text);
            if (textBox1.Text != ce.products.Max(o => o.prod_id).ToString())
            {
                var res = ce.products.Where(o => o.prod_id > val).OrderBy(x => x.prod_id).FirstOrDefault();
                textBox1.Text = res.prod_id.ToString();
                textBox2.Text = res.prod_name.ToString();
                textBox3.Text = res.mfg_date.ToString();
                textBox4.Text = res.exp_date.ToString();
                textBox5.Text = res.price.ToString();
                textBox6.Text = res.company.ToString();
          
            }
            else
            {
                MessageBox.Show("This is the last Record");
               
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int val = Int32.Parse(textBox1.Text);
            if (textBox1.Text != ce.products.Min(o => o.prod_id).ToString())
            {
                var res = ce.products.Where(o => o.prod_id <val).OrderByDescending(x => x.prod_id).FirstOrDefault();
                textBox1.Text = res.prod_id.ToString();
                textBox2.Text = res.prod_name.ToString();
                textBox3.Text = res.mfg_date.ToString();
                textBox4.Text = res.exp_date.ToString();
                textBox5.Text = res.price.ToString();
                textBox6.Text = res.company.ToString();

            }
            else
            {
                MessageBox.Show("This is the first Record");
              
            }

        }
    }
}
