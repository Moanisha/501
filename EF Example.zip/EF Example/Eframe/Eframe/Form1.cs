﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Entity;

namespace Eframe
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Task1Entities1 te = new Task1Entities1();
           //dataGridView1.DataSource = (from s in te.staffs
           //                            select s).ToList();
           //dataGridView1.DataSource = te.staffs.Select(c => new { c.staffno, c.fname, c.lname, c.oposition }).ToList();

//Display staff no ,staff name ,salary and the no of registration a particular staff did
            dataGridView1.DataSource=te.staffs.Select(d=>new{staffnum=d.staffno,Staffname=d.fname+d.lname,amount=d.salary,d.registrations.Count}).ToList();
      
//Display property no,city,and staff's first name
            dataGridView1.DataSource = te.propertyforrents.Select(d => new {d.propertyno,d.city,d.staff.fname}).ToList();
        }
    }
}
