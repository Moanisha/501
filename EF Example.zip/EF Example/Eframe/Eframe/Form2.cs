﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Entity;

namespace Eframe
{
    public partial class Form2 : Form
    {
        Task1Entities1 te;
        public Form2()
        {
            InitializeComponent();
            te = new Task1Entities1();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            var data = te.branches.Select(s => s.branchno);
            foreach (var d in data)
                comboBox1.Items.Add(d);
           

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string bno = comboBox1.Text;
            dataGrid1.DataSource = te.branches.Where(s => s.branchno == bno).Select
                (n=>new{n.branchno,n.city,n.street,n.postcode}).ToList();

        }
    }
}
