﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Eframe
{
    public partial class Form3 : Form
    {
        Task1Entities1 te;
        public Form3()
        {
            InitializeComponent();
            te = new Task1Entities1();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Form3_Load(object sender, EventArgs e)
        {
            //var data = from sf in te.staffs
            //           join rg in te.registrations
            //           on sf.staffno equals rg.staffno
            //           select new { sf.fname, sf.oposition, rg.datejoined };
            //dataGridView1.DataSource = data.ToList();

            var data = te.staffs.Join(te.registrations, d => d.staffno, ry => ry.staffno, (stf, reg) =>
                new { stf.fname, stf.oposition, reg.datejoined }).ToList();
            dataGridView1.DataSource = data;
        }
    }
}
