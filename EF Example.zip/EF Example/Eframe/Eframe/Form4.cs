﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Eframe
{
    public partial class Form4 : Form
    {
        Task1Entities1 te;
        public Form4()
        {
            InitializeComponent();
            te = new Task1Entities1();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string val = textBox1.Text;
                var data = (from s in te.staffs
                            where s.staffno == val
                            select s).FirstOrDefault();
                if (data != null)
                {
                    textBox2.Text = data.fname;
                    textBox3.Text = data.lname;
                    textBox4.Text = data.oposition;
                    textBox5.Text = data.salary.ToString();
                }
                else
                    MessageBox.Show("Invalid staff no");

        }
    }
}
