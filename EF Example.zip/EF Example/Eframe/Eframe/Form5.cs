﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Eframe
{
    public partial class Form5 : Form
    {
        Task1Entities1 te;
        public Form5()
        {
            InitializeComponent();
            te = new Task1Entities1();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string data = textBox1.Text;
            var res = te.disp_branch_bno(data).FirstOrDefault();
            if (res != null)
            {
                textBox2.Text = res.street;
                textBox3.Text = res.city;
                textBox4.Text = res.postcode;
            }
            else
                MessageBox.Show("Invalid");
        }
    }
}
