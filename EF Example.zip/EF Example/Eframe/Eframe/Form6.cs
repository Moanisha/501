﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Entity;
using System.Data.Objects;

namespace Eframe
{
    public partial class Form6 : Form
    {
        Task1Entities1 te;
        public Form6()
        {
            InitializeComponent();
            te = new Task1Entities1();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string val = textBox1.Text;
            ObjectParameter p1=new ObjectParameter("countval",typeof(int));
            te.disp_staff_branch(val, p1);
            MessageBox.Show(p1.Value.ToString());
        }
    }
}
