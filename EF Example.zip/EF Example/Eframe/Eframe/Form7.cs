﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Eframe
{
    public partial class Form7 : Form
    {
        Task1Entities1 te;
        public Form7()
        {
            InitializeComponent();
            te = new Task1Entities1();
        }

        private void Form7_Load(object sender, EventArgs e)
        {
            var q = te.branches.Max(c => c.branchno);
            var input = q.ToString();
            string bno = null;
            var num = input.Substring(1, 3);
            int inc = int.Parse(num) + 1;
            if (inc < 10)
                bno = input.Substring(0, 3) + inc.ToString();
            else if (inc < 100)
                bno = input.Substring(0, 2) + inc.ToString();
            else
                bno = input.Substring(0, 1) + inc.ToString();
            textBox1.Text = bno;
            textBox1.Enabled = false;       
        }
//INSERT A RECORD
        private void button1_Click(object sender, EventArgs e)
        {
            branch b = new branch();
            b.branchno = textBox1.Text;
            b.street = textBox2.Text;
            b.city = textBox3.Text;
            b.postcode = textBox4.Text;
            te.branches.Attach(b);
            te.branches.Add(b);
            int res=te.SaveChanges();
            MessageBox.Show(res.ToString() + "Rows Inserted");
        }
//DELETE A RECORD
    }
}
