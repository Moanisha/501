﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Eframe
{
    public partial class Form8 : Form
    {
        Task1Entities1 te;
        public Form8()
        {
            InitializeComponent();
            te = new Task1Entities1();
        }
//DELETE RECORD
        private void button1_Click(object sender, EventArgs e)
        {
            string inp = textBox1.Text;
            var q = (from s in te.branches
                     where s.branchno == inp
                     select s).FirstOrDefault();
            if (q != null)
            {
                te.branches.Remove(te.branches.Where(c=>c.branchno==inp).FirstOrDefault());
                int res=te.SaveChanges();
                MessageBox.Show(res.ToString() + "rows deleted");
            }
            else
            {
                MessageBox.Show("No records found");
            }
        }
    }
}
