﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Eframe
{
    public partial class Form9 : Form
    {
        Task1Entities1 te;
        public Form9()
        {
            InitializeComponent();
            te = new Task1Entities1();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string data = textBox1.Text;
            var res = te.branches.Where(c => c.branchno == data).FirstOrDefault();
            if (res != null)
            {
                textBox2.Text = res.street;
                textBox3.Text = res.city;
                textBox4.Text = res.postcode;
                textBox1.Enabled = false;
            }
            else
                MessageBox.Show("Invalid");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string data = textBox1.Text;
            branch res = te.branches.Where(c => c.branchno == data).FirstOrDefault();

            res.street= textBox2.Text; 
            res.city= textBox3.Text ;
            res.postcode = textBox4.Text;
 
            int r=te.SaveChanges();
            MessageBox.Show(r.ToString() + "row Updated");
        }
    }
}
