﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Services;
using System.Data;
using System.Data.SqlClient;

namespace jquery_ex1
{
    public partial class autocomplete_example : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        [WebMethod]
        public static string[] Getremarks(string rem)
        {
            List<string> li = new List<string>();
            string constring = "server=pc251449;database=master;integrated security=false;user id=sa;password=password-1";
            SqlConnection con = new SqlConnection(constring);
            string qry = "select remarks from info where remarks like '%" +rem+ "%'"; 
            con.Open();
            SqlCommand cmd = new SqlCommand(qry,con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                li.Add(dr.GetString(0));
            }
            return li.ToArray();
        }
 
    }
}