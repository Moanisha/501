﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.IO;

namespace CaseStudy_FileHandling
{
    class Program
    {
        public static void Main()
        {
            int choice;
            int n; string gt;
           
            do
            {
            Console.WriteLine("Enter the choice \n 1.Display Teams 2.Add new Team 3.Search Team 4.Delete Team 5.Modify Team");
            choice = int.Parse(Console.ReadLine());
            if (choice == 1)
            {
                FileStream fs;
                StreamReader sr;
                if ((File.Exists(@"c:\OOPS\CaseStudy_FileHandling\ipl.csv")))
                {
                    fs = new FileStream(@"c:\OOPS\CaseStudy_FileHandling\ipl.csv", FileMode.Open, FileAccess.ReadWrite);
                    sr = new StreamReader(fs);
                    string str;
                    while ((str = sr.ReadLine()) != null)
                    {
                        Console.WriteLine(str);
                    }
                    sr.Close();
                }
            }
            else if (choice == 2)
            {
                Console.WriteLine("Enter the Number of Rows to be added");
                n = int.Parse(Console.ReadLine());
                Store ob = new Store();
                for (int i = 0; i < n; i++)
                {
                    ob.store_data();
                } 
                ob.save();
            }
            else if (choice == 3)
            {
                Search s = new Search();
                s.search_m();
            }
            else if (choice == 4)
            {
                delete d = new delete();
                d.del();
            }
            else if (choice == 5)
            {
                modify m = new modify();
                m.mod();
            }
                Console.WriteLine("Press any Key to Continue... Press 'N' to end the program...");
                gt = Console.ReadLine();
            } while (gt != "N" && gt != "n");
            
        }

    }
}
