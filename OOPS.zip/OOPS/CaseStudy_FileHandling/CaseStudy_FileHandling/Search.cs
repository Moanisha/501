﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace CaseStudy_FileHandling
{
    class Search
    {

        public void search_m()
        {
            string k;
            string[] res=new string[5];
            int count = 0;
            FileStream fs; int j = 0;
            StreamReader sr;
            if ((File.Exists(@"c:\OOPS\CaseStudy_FileHandling\ipl.csv")))
            {
                fs = new FileStream(@"c:\OOPS\CaseStudy_FileHandling\ipl.csv", FileMode.Open, FileAccess.ReadWrite);
                sr = new StreamReader(fs);
                string str;
                Console.WriteLine("Enter the Key");
                k = Console.ReadLine();
                while ((str = sr.ReadLine()) != null)
                {
                     string[] str1 = str.Split(',',' ');
                    if (k == str1[0])
                    {
                        count++;
                        res[j] = str1[1];
                        j++;
                    }
                }
                if (count == 0)
                {
                    Console.WriteLine("Invalid Key");
                }
                foreach (string s in res)
                {
                    Console.WriteLine(s);
                }
                sr.Close();
            }
       }    
     
    }
}
