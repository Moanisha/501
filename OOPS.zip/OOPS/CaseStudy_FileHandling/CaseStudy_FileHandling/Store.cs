﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace CaseStudy_FileHandling
{
    class Store
    {
        List<matchdetails> teams;
        public Store()
        {
            teams = new List<matchdetails>();
        }
        public void store_data()
        {
            if (teams == null)
            {
                teams = new List<matchdetails>(); 
            }
                Console.WriteLine("Enter the Team Details");
                Console.WriteLine("Enter the Team id");
                int id = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter the Team name");
                string name = Console.ReadLine();
                matchdetails ui = new matchdetails(id, name);
                teams.Add(ui);
        }
        
        public void save()
        {
            FileStream fs;
            StreamWriter sw;
            if (!File.Exists(@"c:\OOPS\CaseStudy_FileHandling\ipl.csv"))
            {
                fs = new FileStream(@"c:\OOPS\CaseStudy_FileHandling\ipl.csv", FileMode.CreateNew, FileAccess.ReadWrite);
                sw = new StreamWriter(fs);
                sw.WriteLine("TEAM_ID,TEAM_NAME");
            }
            else
            {
                fs = new FileStream(@"c:\OOPS\CaseStudy_FileHandling\ipl.csv", FileMode.Append, FileAccess.Write);
                sw = new StreamWriter(fs);
            }
            foreach (matchdetails u in teams)
            {
                string[] values = new string[2] {u.tid.ToString(), u.tname};
                string lastdata = string.Join(",", values);
                sw.WriteLine(lastdata);
            }
            sw.Close(); teams = null;
        }
 
    }
}
