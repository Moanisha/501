﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace CaseStudy_FileHandling
{
    class delete
    {
        List<string> teams;
        public delete()
        {
            teams = new List<string>();
        }

        public void del()
        {
           
            string k; 
            string[] str1=new string[10];
            int count = 0; 
            FileStream fs;
            StreamReader sr;
            if ((File.Exists(@"c:\OOPS\CaseStudy_FileHandling\ipl.csv")))
            {
                fs = new FileStream(@"c:\OOPS\CaseStudy_FileHandling\ipl.csv", FileMode.Open, FileAccess.ReadWrite);
                sr = new StreamReader(fs);
                string str;
                Console.WriteLine("Enter the Key");
                k = Console.ReadLine();
                while ((str = sr.ReadLine()) != null)
                {
                    str1 = str.Split(',', ' ');
                    if (k == str1[0])
                    {

                        count++;
                    }
                    else
                    {
                        teams.Add(str);
                    }
                }
                sr.Close();
                
                if (count == 0)
                {
                     Console.WriteLine("Invalid Key");
                }
                StreamWriter sw;
                FileStream fs1 = new FileStream(@"c:\OOPS\CaseStudy_FileHandling\ipl.csv", FileMode.Create, FileAccess.Write);
                sw = new StreamWriter(fs1);
                foreach (string u in teams)
                {
                    sw.WriteLine(u);
                }
                sw.Close(); 
            }
          }
      }
}

