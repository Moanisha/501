﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CaseStudy_FileHandling
{
    class matchdetails
    {
        public int tid{get; set;}
        public string tname { get; set; }
        public matchdetails(int a, string b)
        {
            tid = a;
            tname = b;    
        }
    }
}
