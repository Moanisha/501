﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Case_Study
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("IPL 2008");
            //Match_Details m = new Match_Details();
            TeamStatus a = new TeamStatus();
            Store_result r = new Store_result();
            int choice; 
            string n;
            Console.WriteLine("1.Add new Team");
            Console.WriteLine("2.Search");
            Console.WriteLine("3.Delete Team");
            Console.WriteLine("4.Display Match Details");
            Console.WriteLine("5.Display Result");
            Console.WriteLine("6.Modify Team");
            Console.WriteLine("7.Display Team");
            do
            {
                Console.WriteLine("Enter the Choice");
                choice = int.Parse(Console.ReadLine());
                if (choice == 1)
                {
                    a.Addition();

                }
                else if (choice == 2)
                {
                    a.search();
                }

                else if (choice == 3)
                {
                    a.delete();
                }

                else if (choice == 4)
                {
                    r.store_data();
                    Console.WriteLine("Enter the Match Number : (1-3)");
                    int match_no = int.Parse(Console.ReadLine());
                    r.display(match_no);
                }
                else if (choice == 5)
                {
                    r.store_result();
                    r.store_data();
                    Console.WriteLine("Enter the Match Number : (1-3)");
                    int match_no = int.Parse(Console.ReadLine());
                    r.display_res(match_no);

                }
                else if (choice == 6)
                {
                    a.modify();
                }
                else if (choice == 7)
                {
                    a.Display();
                }

                Console.WriteLine("Press any Key to Continue... Press 'N' to end the program...");
                n = Console.ReadLine();
            } while (n != "N" && n != "n");

        }
    }
}
