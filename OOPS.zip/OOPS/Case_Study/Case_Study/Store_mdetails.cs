﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace Case_Study
{
    
    class Store_mdetails
    {
        public List<string[]> mtch = new List<string[]>();
        string[] m1 = new string[8] { "KKR_Vs_RCB","RCB", "Field", "4/18/2008", "Asad Rauf", "RE Koertzen", "M Chinnaswamy Stadium", "Bangalore" };
        string[] m2 = new string[8] {"CSK_Vs_KIXP","CSK","Bat","4/19/2008","MR Benson","SL Shastri","Punjab Cricket Association Stadium","Chandigarh" };
        string[] m3 = new string[8] { "RR Vs DD", "RR", "Bat", "4/19/2008", "Aleem Dar", "GA Pratapkumar", "Feroz Shah Kotla", "Delhi" };
        public void store_data()
        {
            mtch.Add(m1);
            mtch.Add(m2);
            mtch.Add(m3);
        }
        public void display(int k)
        {   
            for (int i = 0; i < 8; i++)
            {
                Console.WriteLine(mtch[k-1][i]);
               
            }
        }
    }

    }

