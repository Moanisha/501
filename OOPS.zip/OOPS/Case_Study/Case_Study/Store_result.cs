﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Case_Study
{
    class Store_result:Store_mdetails
    {
        List<string[]> res = new List<string[]>();
        string[] r1 = new string[3] {"Winner:KKR","Win_by_runs:140","Player:BB_McCullum" };
        string[] r2 = new string[3] {"Winner:CSK","Win_by_runs:33","Player:MEK Hussey" };
        string[] r3 = new string[3] {"Winner:DD","Win_by_wickets:9","Player:MF Maharoof" };
        public void store_result()
        {
            res.Add(r1);
            res.Add(r2);
            res.Add(r3);

        }
        public void display_res(int k)
        {
            Console.WriteLine(mtch[k - 1][0]);
            for (int i = 0; i < 3; i++)
            {
               
                Console.WriteLine(res[k - 1][i]);
            }
        }
    }
}
