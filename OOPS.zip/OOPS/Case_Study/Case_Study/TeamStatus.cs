﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Case_Study
{
    //Add a Team Name
    public class TeamStatus
    {
        public SortedList<int, string> l = new SortedList<int, string>();
        public int k = 1;
        public void Addition()
        {
            string tname;
            int no;
            Console.WriteLine("Enter the Number of Teams to be Added");
            no = int.Parse(Console.ReadLine());
           
            for (int i = 0; i < no; i++)
            {
                Console.WriteLine("Enter the Team Name:");
                tname = Console.ReadLine();
                l.Add(k++,tname);
            }
            foreach (KeyValuePair<int,string> s in l)
            {
                Console.WriteLine("{0}-{1}",s.Key,s.Value);
            }    
        }

        //Display Team
        public void Display()
        {
            foreach (KeyValuePair<int, string> s in l)
            {
                Console.WriteLine("{0}-{1}", s.Key, s.Value);
            }
        }

        //Search a Team
        public void search()
        {
            int ky;
            Console.WriteLine("Enter the Key to be Searched");
            ky = int.Parse(Console.ReadLine());
            if(l.ContainsKey(ky))
            Console.WriteLine("The element in the specified Key {0} is {1}", ky, l[ky]);
            else
                Console.WriteLine("The key is not valid");
        }


        //Delete Team name
        public void delete()
        {
            int delkey;
            Console.WriteLine("Enter the Key for which the value must be Deleted");
            delkey = int.Parse(Console.ReadLine());
            if (l.ContainsKey(delkey))
            {
                Console.WriteLine("The element in the specified Key {0},{1}", delkey,l[delkey]);
                l.RemoveAt(delkey);   
            }
            else
                Console.WriteLine("The key is not valid"); 
        }


        //Modify Team Name
        public void modify()
        {
            int modkey;
            string new_team;
            Console.WriteLine("Enter the Key which has to be modified");
            modkey = int.Parse(Console.ReadLine());
            if (l.ContainsKey(modkey))
            {
                Console.WriteLine("Enter the Edited Team Name");
                new_team = Console.ReadLine();
                l[modkey] = new_team;
                Console.WriteLine("The Edited element in the Specified Key {0},{1}",modkey,l[modkey]);
            }
            else
                Console.WriteLine("The key is not valid");
        }
        
    }
}
