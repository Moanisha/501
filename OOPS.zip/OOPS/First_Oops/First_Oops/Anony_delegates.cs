﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace First_Oops
{
    class Anony_delegates
    {
        delegate void operation();

        //static void Main(string[] args)
        //{
        //    operation obj = delegate
        //    {
        //        Console.WriteLine("Anonymous");
        //    };
        //    obj();

        //    Console.ReadLine();
        //} 
    }
}
