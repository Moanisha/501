﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace First_Oops
{
    class Array_concept
    {
        public static void Main()
        {
            ////Single dimensional array
            //int[] arr1 = new int[5];
            //Console.WriteLine("Enter the input");
            //for (int i = arr1.GetLowerBound(0); i < arr1.Length; i++)
            //{
            //    arr1[i] = int.Parse(Console.ReadLine());
            //}

            ////Reverse
            //int[] temp = arr1;
            //Array.Reverse(temp);
            //Console.WriteLine("Reverse");
            //foreach (var n in temp)
            //{
            //    Console.Write(n);
            //}

            ////Sort
            //int[] temp1 = arr1;
            //Array.Sort(temp1);
            //Console.WriteLine();
            //Console.WriteLine("Sort");
            //foreach (var n in temp1)
            //{
            //    Console.Write(n); Console.Write(" ");
            //}

            ////Resize
            //Console.WriteLine();
            //Console.WriteLine("Resize");
            //Array.Resize(ref temp1, 2);
            //Console.WriteLine(temp1.Length);

            ////2 Dimensional Array
            //int[,] arr2 = new int[4, 2];
            //for (int i = arr2.GetLowerBound(0); i < arr2.GetLength(0); i++)
            //{
            //    for (int j = arr2.GetLowerBound(1); j < arr2.GetLength(1); j++)
            //    {
            //        arr2[i, j] = int.Parse(Console.ReadLine());
            //    }
            //}
            //foreach (var n in arr2)
            //{
            //    Console.WriteLine(n);
            //}


            //Jagged Array

            int[][] jag = new int[3][];
            jag[0] = new int[5] { 0, 1, 2, 3, 4 };

            jag[1] = new int[4];
            jag[1][0] = 11;
            jag[1][1] = 22;
            jag[1][2] = 33;
            jag[1][3] = 44;

            jag[2] = new int[3] { 20, 30, 40 };


            Console.WriteLine("Jagged OP");
            int[] arr4 = new int[5]; 
            for (int i = 0; i < jag.Length; i++)
            {
                arr4 = jag[i];
                for (int j = 0; j < arr4.Length; j++)
                {
                    Console.Write(jag[i][j]);
                    Console.Write(" ");
                }
                Console.WriteLine();
            }

        }
    }
}
