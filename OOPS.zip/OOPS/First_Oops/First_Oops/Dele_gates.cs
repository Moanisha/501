﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace First_Oops
{
    //This example demonstrates about Delegates
    class Dele_gates
    {
        public delegate void compute(int val1,int val2);
        public void Show_output()
        {
            Console.WriteLine("THis is from output method");
        }
        //public static void Main()
        //{
        //    Dele_gates ob = new Dele_gates();
        //    //ob.Show_output();
        //    call c1 = new call(ob.Show_output);

        //    c1 += new call(ob.Show_output);         //Call one time three times output
        //    c1 += new call(ob.Show_output);
        //    c1();                                   //Without knowing the function one function can be called using a proxy
            
        //    compute co = new compute(ob.add);
        //    co(4, 10);
        //  //co = new compute(ob.mul);       //Single cast delegate
        //    co += new compute(ob.mul);       //Multi cast delegate
        //    co(5, 10);

        //}
        public void add(int x, int y)
        {
            Console.WriteLine(x+y);
        }
        public void mul(int a, int b)
        {
            Console.WriteLine(a * b);
        }
   }
    public delegate void call();
}
