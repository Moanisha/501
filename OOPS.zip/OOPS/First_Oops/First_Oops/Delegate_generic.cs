﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace First_Oops
{
    class Delegate_generic
    {
        
        public delegate void compute<T1,T2>(T1 a,T2 b);
        //public static void Main()
        //{
        //    Delegate_generic ob = new Delegate_generic();  
        //    compute<int,int> co = new compute<int,int>(ob.add);
        //    co(4, 10);
        //    compute<double, double> mu = new compute<double, double>(ob.mult);
        //    mu(4.5, 1.0);
        //}
        public void add(int a, int b)
        {
            Console.WriteLine(a+b);
        }
        public void mult(double a, double b)
        {
            Console.WriteLine(a*b);
        }
   }
}

