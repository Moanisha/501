﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace First_Oops
{    
    public delegate void winprice(); //Declaration of delegate
   //Publisher Class
    class Delegates_Events
    {
        public static int count;
        public event winprice Valuable_User; //Declaration of event
        public void purchase()
        {
            count++;
            Console.WriteLine("Thanks for purchasing the product");
            if (count % 3 == 0)
            {
                Valuable_User.Invoke();               //Raise the event
            }
        }
     }
   //Subscriber Class
    class Shopping_cart
    {
        public static void greeting()        //Matches with delegate
        {
            Console.WriteLine("You are a lucky winner of iPhone 7!!");
        }
        //static void Main(string[] args)
        //{
        //    int choice;
        //    Delegates_Events ob = new Delegates_Events();  //In events only += or -=
        //    ob.Valuable_User += new winprice(greeting);
        //    do
        //    {
        //        ob.purchase();
        //        Console.WriteLine("Do you want to continue? 1.Yes 2.No");
        //        choice = int.Parse(Console.ReadLine());
        //    } while (choice == 1);
        //}
    
    }
}
