﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace First_Oops
{
    //This example demonstrates about File Handling
    class File_Handlin
    {
        //public static void Main()
        //{
        //    //To view the Drive information and create new folder

        //    DriveInfo[] dinfo = DriveInfo.GetDrives();
        //    foreach (DriveInfo i in dinfo)
        //    {
        //        Console.WriteLine(i.Name);
        //        //Console.WriteLine(i.AvailableFreeSpace);
        //    }
        //    DirectoryInfo dir = new DirectoryInfo("D:\\Moanisha");
        //    dir.Create();

        //}

        //public static void Main()  //To explain file stream
        //{
        //    string n;
        //    string data;
        //    do{
        //    //Create a file
        //  FileStream fs = new FileStream(@"D:\Moanisha\Demo.txt", FileMode.Append, FileAccess.Write, FileShare.None);
        //    //fs.Close();
        //    //Write in File
        //    StreamWriter sw = new StreamWriter(fs);
        //    Console.WriteLine("Enter the Data");
        //    data = Console.ReadLine();
        //    sw.WriteLine(data);
            
            
            
        //    Console.WriteLine("Press any Key to Continue... Press 'N' to end the program...");
        //    n = Console.ReadLine(); sw.Close();
        //    } while (n != "N" && n != "n");
            
        //}

    }
}
