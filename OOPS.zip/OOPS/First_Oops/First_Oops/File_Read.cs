﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace First_Oops
{
    class File_Read
    {
        //This example demonstrates about Reading a File
        //public static void Main()
        //{
        //    string str;
        //    FileStream fs = new FileStream(@"D:\Moanisha\Demo.txt", FileMode.Open, FileAccess.ReadWrite, FileShare.None);
        //    StreamReader rd = new StreamReader(fs);
        //    while ((str = rd.ReadLine()) != null)
        //    {
        //        Console.WriteLine(str);
        //    }
            
        //    fs.Close();
            
        //}
    }
}
