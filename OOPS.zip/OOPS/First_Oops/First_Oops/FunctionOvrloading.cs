﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace First_Oops
{
    //THis example demonstrates about Function Overloading and Return Type
    class FunctionOvrloading
    {
        //void manipulation(int a, int b)
        //{
        //    int res;
        //    res = a + b;
        //    Console.WriteLine("The sum of {0} and {1} is {2}", a, b, res);
        //}
        //void manipulation(int a, int b)
        //{
        //    int res;
        //    res = a * b;
        //    Console.WriteLine("The sum of {0},{1} is {2}", a, b, res);
        //}
        //public static void Main()
        //{
        //    FunctionOvrloading ob = new FunctionOvrloading();
        //    ob.manipulation(2, 10);
        //    ob.manipulation(2, 44);
        //}
        int manipulation(int a, int b)
        {
            
            return (a+b);
        }
        int manipulation(int a, int b,int c)
        {
            int res;
            res = a * b*c ;
            return res;
        }
        //public static void Main()
        //{
        //    FunctionOvrloading ob = new FunctionOvrloading();
        //    int val1=ob.manipulation(2, 10);
        //    int val2=ob.manipulation(2, 5,5);
        //    Console.WriteLine("The output is {0}", val1);
        //    Console.WriteLine("The output is {0}", val2);

        //}
    }
}
