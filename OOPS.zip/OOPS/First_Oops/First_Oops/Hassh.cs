﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace First_Oops
{
    //THis example demonstrates about HashTable
    class Hassh
    {
        //public static void Main()
        //{
        //    Hashtable ht = new Hashtable();
        //    ht.Add("Hi","Welcome");
        //    ht.Add("621976", "Moanisha");
        //    ht.Add("Moanisha", "B.E CSE");
        //    ht.Add("ddd",":)");
        //    Console.WriteLine(ht.Count);

        //    //Clear the HashTable
        //    //ht.Clear();
        //    //Console.WriteLine(ht.Count);

        //    //ContainsKey in Hashtable
        //    Console.WriteLine( ht.ContainsKey("Hi"));
        
        //    //ContainsValue in Hashtable
        //    Console.WriteLine(ht.ContainsValue("Moanisha"));

        //    //Display all elements in Hashtable
        //    Console.WriteLine(ht["621976"]);
        //    ICollection ic = ht.Keys;
        //    foreach (object o in ic)
        //    {
        //        Console.WriteLine(ht[o]);
        //    }
        //}
    }
}
