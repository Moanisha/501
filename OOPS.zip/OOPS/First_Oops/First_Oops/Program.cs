﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace First_Oops
{
    class Program : Student
    {
        public int x;
        int y;
        void accept()
        {
            x = 30;
            y = 20;
            add();
        }
        void add()
        {
            int total;
            total = x + y;
            Console.WriteLine("The sum : {0} + {1} = {2}", x, y, total);
        }
 //       static void Main(string[] args)
 //       {
 //           Program ob = new Program();
 //           ob.accept();
 ////           ob.add();
 //           Student s = new Student();
 //           ob.store();
 //           ob.display();
 //       }
    }
    class Student
    {
        public int sid;
        protected string sname;
        protected void store()
        {
            sid = 10;
            sname = "CHN17ID001";
        }
        protected void display()
        {
            Console.WriteLine("Student id : {0}", sid);
            Console.WriteLine("Student Name:{0}", sname);
        }
        //static void Main(string[] args)
        //{
        //    Program ob = new Program();
        //    // ob.accept();
        //    //          ob.add();
        //    Student s = new Student();
        //    s.store();
        //    s.display();
        //}
    }
}
