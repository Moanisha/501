﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace First_Oops
{
    class Queu
    {
        //public static void Main()
        //{
        //    Queue q = new Queue();
        //    q.Enqueue("Hi");
        //    q.Enqueue("Dev");
        //    q.Enqueue("You are stupid");
        //    foreach (object o in q)
        //    {
        //        Console.WriteLine(o);
        //    }
        //    q.Dequeue();
        //    foreach (object o in q)
        //    {
        //        Console.WriteLine(o);
        //    }
        //    object res = q.Peek();
        //    Console.WriteLine(res);
        //}
    }
}
