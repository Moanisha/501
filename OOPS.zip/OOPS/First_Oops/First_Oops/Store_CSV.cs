﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace First_Oops
{
    class Store_CSV
    {

        List<user_info> users;
        public Store_CSV()
        {
            users = new List<user_info>();
        }
        public void store_data()
        {
            if (users == null)
            {
                users = new List<user_info>(); 
            }
                Console.WriteLine("Enter the user details");
                Console.WriteLine("Enter the userid");
                int id = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter the name");
                string name = Console.ReadLine();
                DateTime temp;
                while (1 == 1)
                {
                    Console.WriteLine("Enter the date in the form of dd-MM-yyyy format");
                    string date = Console.ReadLine();
                    bool b = DateTime.TryParseExact(date, "d-M-yyyy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out temp);
                    if (b == true)
                        break;
                    else if (b == false)
                    {
                        Console.WriteLine("Enter the date in Correct format");
                    }
                }
                //  users.Add(new user_info(id,name,temp));
                user_info ui = new user_info(id, name, temp);
                users.Add(ui);
        }
        //public static void Main()
        //{
        //    Store_CSV ob = new Store_CSV();
        //    ob.store_data();
        //    ob.store_data();
        //    ob.save();
        //}
        public void save()
        {
            FileStream fs;
            StreamWriter sw;
            if (!File.Exists(@"D:\Moanisha\users.csv"))
            {
                fs = new FileStream(@"D:\Moanisha\users.csv", FileMode.CreateNew, FileAccess.ReadWrite);
                sw = new StreamWriter(fs);
                sw.WriteLine("UID,UNAME,DOJ");
            }
            else
            {
                fs=new FileStream(@"D:\Moanisha\users.csv", FileMode.Append, FileAccess.ReadWrite);
                sw = new StreamWriter(fs);
            }
            foreach (user_info u in users)
            {
                string[] values = new string[3] { u.uid.ToString(), u.uname, u.doj.ToShortDateString()};
                string lastdata = string.Join(",", values);
                sw.WriteLine(lastdata);
            }
            sw.Close(); users = null;
        }
    }
}