﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace First_Oops
{
    class bread
    {
        //public static void Main()
        //{
        //    string name; int ag; string des;
        //    FileStream fs = new FileStream(@"D:\Moanisha\Demo.txt", FileMode.Open, FileAccess.ReadWrite, FileShare.None);
        //    BinaryReader br = new BinaryReader(fs);
        //    name=br.ReadString();
        //    ag = br.ReadInt32();
        //    des = br.ReadString();
        //    Console.WriteLine("{0},{1},{2}",name,ag,des);
        //    fs.Close();
            
        //}
    }
}
