﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace First_Oops
{
    //This example demonstrates about Binary Reader
    class bwrite
    {
        //public static void Main()
        //{
        //    string ename = "Moanisha";
        //    int age = 65;
        //    string designation = "PAT";
        //    FileStream fs = new FileStream(@"D:\Moanisha\Demo.txt", FileMode.Open, FileAccess.ReadWrite, FileShare.None);
        //    BinaryWriter bw = new BinaryWriter(fs);
        //    bw.Write(ename);
        //    bw.Write(age);
        //    bw.Write(designation);
        //    bw.Close();
        //}
    }
}
