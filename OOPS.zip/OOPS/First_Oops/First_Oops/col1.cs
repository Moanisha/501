﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace First_Oops
{
    //This example demonstrates about Collections
    class col1
    {
        //public static void Main()
        //{
        //    ArrayList al = new ArrayList();
        //    Console.WriteLine(al.Count);
        //    al.Add("welcome");
        //    al.Add(20);
        //    al.Add(true);
        //    al.Add('A');
        //    al.Add("World");
        //    Console.WriteLine(al.Count);
        //    al.Remove(20);
        //    Console.WriteLine(al.Count);
        //    for (int i = 0; i < al.Count; i++)
        //    {
        //        Console.WriteLine(al[i]);
        //    }
        //    Console.WriteLine(al[1]);
        //    al.RemoveAt(0);
            
        //    foreach (var n in al)
        //    {
        //        Console.WriteLine(n);
        //    }
        //}
    }
}
