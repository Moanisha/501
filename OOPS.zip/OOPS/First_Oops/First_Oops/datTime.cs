﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace First_Oops
{
    class datTime
    {
        //public static void Main()
        //{
        //    DateTime dob = new DateTime(1994, 06, 14, 7, 10, 24);
           

        //    //Date Time Properties
        //    Console.WriteLine("Year:{0}",dob.Year);
        //    Console.WriteLine("Month:{0}", dob.Month);
        //    Console.WriteLine("Day:{0}", dob.Day);
        //    Console.WriteLine("Hour:{0}", dob.Hour);
        //    Console.WriteLine("Minute:{0}", dob.Minute);
        //    Console.WriteLine("Second:{0}", dob.Second);
        //    Console.WriteLine("Millisecond:{0}", dob.Millisecond);
        //    Console.WriteLine("Day of Week:{0}", dob.DayOfWeek);
        //    Console.WriteLine("Day of Year: {0}", dob.DayOfYear);
        //    Console.WriteLine("Time of Day:{0}", dob.TimeOfDay);
        //    Console.WriteLine("Tick:{0}", dob.Ticks);
        //    Console.WriteLine("Kind:{0}", dob.Kind);

        //    //Addition and Subtraction
        //    DateTime cdate = DateTime.Now;
        //    Console.WriteLine(cdate);
        //    TimeSpan val = new TimeSpan(30, 0, 0, 0);
        //    DateTime amonthafter = cdate.Add(val);
        //    DateTime amonthbefore = cdate.Subtract(val);
        //    Console.WriteLine("Addition of 30 days to Current Date {0}",amonthafter);
        //    Console.WriteLine("Subtraction of 30 days to Current Date {0}", amonthbefore);

        //    // Add Years and Days  
        //    Console.WriteLine("Add 2 years {0}",cdate.AddYears(2));
        //    Console.WriteLine("Add 12 days {0}",cdate.AddDays(12));
        //    // Add Hours, Minutes, Seconds, Milliseconds, and Ticks  
        //    Console.WriteLine("Add 4 hours {0}",cdate.AddHours(4));
        //    Console.WriteLine("Add 15 min {0}",cdate.AddMinutes(15));
        //    Console.WriteLine("Add 45 sec {0}",cdate.AddSeconds(45));
        //    Console.WriteLine("Add 200 msec {0}",cdate.AddMilliseconds(200));
        //    Console.WriteLine("Add 5000 ticks {0}", cdate.AddTicks(5000));


        //    Console.WriteLine("d: " + cdate.ToString("d"));

        //    string dt = "5/5/2017 7:10:24 AM";
        //    DateTime sdt = DateTime.Parse(dt);
        //    Console.WriteLine(sdt);

        //    DateTime temp;
        //    string   date = "2011-29-01 12:00 am";
        //    DateTime.TryParseExact(date, "yyyy-dd-MM hh:mm tt", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out temp);
        //    Console.WriteLine(temp);
        //}
    }
}
