﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace First_Oops
{
    //This example demonstrates about dictionary
    class dict
    {
        //public static void Main()
        //{
        //    Dictionary<int, string> d = new Dictionary<int, string>();
        //    d.Add(1, "Apple");
        //    d.Add(2, "Orange");
        //    d.Add(3, "Papaya");
        //    Console.WriteLine(d.Count);
        //    Console.WriteLine(d[1]);
        //     foreach (KeyValuePair<int,string> i in d)
        //     {
        //         Console.WriteLine("Key {0} Value {1}",i.Key,i.Value);
        //     }
        //}

        //public static void Main()
        //{
        //    Dictionary<int, string> d = new Dictionary<int, string>();
        //    d.Add(1, "Apple");
        //    d.Add(2, "Orange");
        //    d.Add(3, "Papaya");
        //    Console.WriteLine(d.Count);
        //    Console.WriteLine(d[1]);
        //    List<int> l = new List<int>(d.Keys);
        //    foreach (int i in l)
        //    {
        //        Console.WriteLine(d[i]);
        //    }
            
        //}
    }
}
