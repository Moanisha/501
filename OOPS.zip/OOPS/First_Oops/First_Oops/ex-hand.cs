﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace First_Oops
{
    //This example demonstrates about Exception Handling
    class ex_hand
    {
        //public static void Main()
        //{

        //    int x = 0, y = 0, z = 0;
        //    try  //This code can throw exception at run time
        //    {
        //        x = int.Parse(Console.ReadLine());
        //        y = int.Parse(Console.ReadLine());
        //        z = x / y;
        //        Console.WriteLine("The output is {0}", z);
        //    }
        //    catch (DivideByZeroException e) //If any exception happen it should be handled here
        //    {
        //        Console.WriteLine(e.Message);
        //        Console.WriteLine("Re enter");
        //        try
        //        {
        //            x = int.Parse(Console.ReadLine());
        //            y = int.Parse(Console.ReadLine());
        //            z = x / y;
        //            Console.WriteLine("The output is {0}", z);
        //        }
        //        catch(Exception f)
        //        {
        //            Console.WriteLine(f.Message);
        //        }
        //        //    Console.WriteLine("Denominator should not be zero \n {0} \n {1} \n {2} \n {3} \n {4}", e.Message, e.TargetSite, e.StackTrace, e.HelpLink, e.Source);
        //    }
        //    catch (FormatException e) //If any exception happen it should be handled here
        //    {
        //        Console.WriteLine("Incorrect Format \n {0} \n {1} \n {2} \n {3} \n {4}", e.Message, e.TargetSite, e.StackTrace, e.HelpLink, e.Source);
        //    }
        //    catch (Exception e)
        //    {
        //        Console.WriteLine(e.Message);
        //    }

        //    finally
        //    {
        //        Console.WriteLine("THANKS");
        //    }
        //}
    }
}
