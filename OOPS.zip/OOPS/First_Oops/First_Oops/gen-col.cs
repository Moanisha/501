﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace First_Oops
{
    //This example demonstrates about generic collections
    class gen_col
    {
        //public static void Main()
        //{
        //    List<int> l = new List<int>();
        //    l.Add(2);
        //    l.Add(87);
        //    l.Add(78);
        //    l.Add(350);
        //    foreach (int i in l)
        //    {
        //        Console.WriteLine(i);
        //    }
        //    Console.WriteLine(l.Count);
        //    l.RemoveAt(2);
        //    Console.WriteLine(l.Count);

        //    emp e1 = new emp();
        //    e1.EID = 621976;
        //    e1.NAME = "Moanisha";
        //    emp e2 = new emp();
        //    e2.EID = 621992;
        //    e2.NAME = "Siva";
        //    emp e3 = new emp();
        //    e3.EID = 621459;
        //    e3.NAME = "Mano";
        //    List<emp> l1 = new List<emp>();
        //    l1.Add(e1);
        //    l1.Add(e2);
        //    l1.Add(e3);
        //    foreach (emp e in l1)
        //    {
        //        Console.WriteLine("Eid is:{0} Name is :{1}",e.EID,e.NAME);
        //    }
           
        //}
    }
    class emp
    {
        private int eid;
        public int EID
        {
            get
            {
                return eid;
            }
            set
            {
                eid = value;
            }
        }
        private string name;
        public string NAME
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }
    }
}
