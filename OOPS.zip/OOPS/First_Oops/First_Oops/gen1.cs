﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace First_Oops
{
    //THis example demonstrates applying generics to class
    class gen1 <T>
    {
        public T data1;
        public gen1(T data1)
        {
            this.data1 = data1;
        }
        public void display()
        {
            Console.WriteLine("The output is {0}",data1);
        }
    }
    class gen
    {
        //public static void Main()
        //{
        //    gen1<int> ob = new gen1<int>(5);
        //    ob.display();
        //    gen1<string> ob1 = new gen1<string>("Welcome");
        //    ob1.display();
        //}
    }
}
