﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace First_Oops
{

    //This example demonstrates about generics-runtime datatype
    class generic_example
    {
        public void show <T>(T data)
        {
            Console.WriteLine("The value is {0}",data);
        }
        //public static void Main()
        //{
        //    generic_example ob = new generic_example();
        //    ob.show("hi");
        //    ob.show(1);
        //    ob.show(true);
        //    ob.show('A');
        //    ob.show(15.667758);
        //}
    }
}
