﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace First_Oops
{
    //This example demonstrates about interface
    interface i1
    {
        void area();
    }
    interface i2
    {
        void are();
    }
    class inter:i1,i2
    {
        public void area()
        {
            Console.WriteLine("Interface");
        }

        public void are()
        {
            Console.WriteLine("Interface2");
        }
        //public static void Main()
        //{
        //    inter ob = new inter();
        //    ob.area();
        //    ob.are();
        //}
    }
}
