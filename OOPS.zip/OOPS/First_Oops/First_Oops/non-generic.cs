﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace First_Oops
{
    //This example demonstrates about non-generic example
    class non_generic
    {
        public void show(int data)
        {
            Console.WriteLine("The value is {0}", data);
        }
        public void show(string str)
        {
            Console.WriteLine("The value is {0}", str);
        }
        //public static void Main()
        //{
        //    non_generic ob = new non_generic();
        //    ob.show("hi");
        //    ob.show(7);
        //}
    }
}
