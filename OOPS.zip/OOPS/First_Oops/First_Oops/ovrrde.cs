﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace First_Oops
{
    //This example demonstrates about Overriding
    class mammal
    {
        public virtual void move()
        {
            Console.WriteLine("Mammal can Move");
        }
        //public static void Main()
        //{
        //    mammal m = new mammal();
        //    m.move();
        //    m = new human();
        //    m.move();
        //    m = new whale();
        //    m.move();
        //}
    }
    class whale:mammal
    {
        public override void move()
        {
            Console.WriteLine("Moving using Legs");
        }
    }
    class human:mammal
    {
        public override void move()
        {
            Console.WriteLine("Moving using Limbs");
        }
    }
}
