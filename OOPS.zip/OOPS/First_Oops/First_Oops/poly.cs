﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace First_Oops
{
    class poly
    {
        int p, q;
        public void accept(int i,int j)
        {
            p = i;
            q = j;
        }
        public void produce()
        {
            Console.WriteLine("The values are {0} and {1}", p, q);
        }
        //public static void Main()
        //{
        //    poly pol = new poly();
        //    pol.accept(10, 20);
        //    pol.produce();
        //    Console.ReadLine();
        //}
    }
}
