﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace First_Oops
{
    //This example demonstrates Private Constructor
    class employ
    {
        private employ()
        {  
            Console.WriteLine("The private constructor ");
        }
        public static void Salary()
        {
            Console.WriteLine("Private");
        }
    }
    class det
    {
        //static void Main()
        //{
           
        //    employ.Salary();
        //}
    }
}
