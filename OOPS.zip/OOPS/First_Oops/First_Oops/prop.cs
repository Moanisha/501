﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace First_Oops
{
    //THis example demonstrates Properties
    class marker
    {
        private string color="black";
        public string COLOR
        {
            get
            {
                return color;
            }
            //set
            //{
            //    color = value;
            //}
        }
    }
    class callmarker
    {
        //public static void Main()
        //{
        //    marker ob = new marker();
        //    //ob.COLOR = "blue";
        //    Console.WriteLine(ob.COLOR);
        //}

    }
}
