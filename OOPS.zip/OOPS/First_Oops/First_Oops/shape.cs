﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace First_Oops
{
    //This example demonstrates Abstract Class
    public abstract class shape
    {
        public abstract void area();
        public void show()
        {
            Console.WriteLine("HI");
        }
    }
    class square : shape
    {
        //public static void Main()
        //{
        //    square s = new square();
        //    s.area();
        //    s.show();
        //}
        public override void area()
        {
            Console.WriteLine("Area of square");
        }
    }
}
