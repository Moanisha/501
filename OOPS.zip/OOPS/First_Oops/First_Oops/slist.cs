﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace First_Oops
{
    class slist
    {
        //public static void Main()
        //{
        //    SortedDictionary<int, string> d = new SortedDictionary<int, string>();
        //    d.Add(5, "Apple");
        //    d.Add(2, "Orange");
        //    d.Add(3, "Papaya");
        //    Console.WriteLine(d.Count);
         
        //    Console.WriteLine(d[2]);
        //    foreach (KeyValuePair<int, string> i in d)
        //    {
        //        Console.WriteLine("Key {0} Value {1}", i.Key, i.Value);
        //    }
        //}
        
    }
}
