﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace First_Oops
{
    class sortlis
    {
        //public static void Main()
        //{
        //    SortedList sl = new SortedList();
        //    sl.Add(3, "Welcome");
        //    sl.Add(2, "Moanisha");
        //    sl.Add(5, "B.E CSE");
        //    sl.Add(1, ":)");
        //    ICollection ic = sl.Keys;
        //    foreach (object o in ic)
        //    {
        //        Console.WriteLine(sl[o]);
        //    }
        //}
    }
}
