﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace First_Oops
{
    class stak2
    {
        //public static void Main()
        //{
        //    Stack s = new Stack();
        //    s.Push("Mano,Dev");
        //    s.Push("Mental");
        //    Console.WriteLine(s.Count);
        //    //object res=s.Pop();
        //    //Console.WriteLine(res);
        //    object res=s.Peek();
        //    Console.WriteLine(res);
        //    foreach (object o in s)
        //    {
        //        Console.WriteLine(o);
        //    }
        //}
    }
}
