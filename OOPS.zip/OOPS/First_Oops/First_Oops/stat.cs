﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace First_Oops
{
    //THis example demonstrates static constructor
      public class employee
    {
          static employee()
          {
              Console.WriteLine("The static constructor ");
          }
        public static void Salary()
        {
            Console.WriteLine("The Salary method");
        }
    }
    class details
    {
        //static void Main()
        //{

        //    employee.Salary();

        //}
  }
}

