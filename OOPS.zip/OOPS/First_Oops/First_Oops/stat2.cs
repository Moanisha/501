﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace First_Oops
{
    //This example is used to demonstrate Static Variable
    class stat2
    {
        static int info;
        public int another;
        //public static void Main()
        //{
        //    stat2 ob1 = new stat2();
        //    stat2 ob2 = new stat2();
        //    ob1.change();
        //    ob1.display();
        //    ob2.change();
        //    ob2.display();
        //}
        public void display()
        {
            Console.WriteLine("Info {0}", info);
            Console.WriteLine("Another {0}", another);
        }
        public void change()
        {
            info++;
            another++;
        }
    }
}
