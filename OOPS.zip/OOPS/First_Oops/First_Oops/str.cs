﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace First_Oops
{
    class str
    {
        //public static void Main()
        //{
        //    string des = @"Mano\n2-java";
        //    string name = "Mano\n2-java";
        //    Console.WriteLine(des);
        //    Console.WriteLine(name);

        //    //Substring
        //    name = "Dev is a c# expert";
        //    Console.WriteLine(name.StartsWith("DEV"));
        //    Console.WriteLine(name.IndexOf("c#"));
        //    string sub = name.Substring(3);
        //    Console.WriteLine(sub);

        //    //Pad
        //    string pa=name.PadRight(20,'*');
        //    Console.WriteLine(pa);
        //    string pal = name.PadLeft(30);
        //    Console.WriteLine(pal);

        //    //Trim
        //    string tri = pal.Trim();
        //    Console.WriteLine(tri);

        //    //Case
        //    string na = "dev";
        //    Console.WriteLine(na.ToUpper());
        //    string da = "DDDDDDDEEEEEVVVVV";
        //    Console.WriteLine(da.ToLowerInvariant());
                  
        //    //Split and Join     
        //    string[] spl = name.Split();
        //    foreach (var item in spl)
        //    {
        //        Console.WriteLine(item);
        //    }
        //    string jo = string.Join("_", spl);
        //    Console.WriteLine(jo);

        //    //Concatenate
        //    string con = string.Concat(spl);
        //    Console.WriteLine(con);

        //    string cat = string.Concat("Dev ", "Expert");
        //    Console.WriteLine(cat);

        //    //Replace
        //    string rep = name.Replace("Dev", "IndraDev");
        //    Console.WriteLine(rep);

            
            
        //}
    }
}
