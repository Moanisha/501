﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace First_Oops
{
    //THis example demonstrates about this keyword
    class tis
    {
        public int sid;
        public string sname;
        public void accept(int sid,string sname)
        {
            this.sid = sid;
            this.sname = sname;
        }
        public void display()
        {
            Console.WriteLine("Student id: {0} Student Name:{1}", sid, sname);
        }
        //public static void Main()
        //{
        //    tis ob = new tis();
        //    ob.accept(500, "Moanisha");
        //    ob.display();
        //}
    }
}
