﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace First_Oops
{
    //This example demonstrates about user defined exception
    
    public class voting : Exception
    {
        public string displayerror()
        {
            return "You are not eligible for voting"; 
        }
    }
    class user_ex_hand
    {
        int age;
        void verifyage()
        {
            if (age < 18)
                throw new voting();
        }
        //public static void Main()
        //{
        //    user_ex_hand ud=new user_ex_hand();
        //    ud.age=16;
        //    try
        //    {
        //        ud.verifyage();
        //    }
        //    catch(voting v)
        //    {
        //        Console.WriteLine(v.displayerror());
        //    }
        //}
    }
}
