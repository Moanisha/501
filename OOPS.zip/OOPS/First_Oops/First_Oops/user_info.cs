﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace First_Oops
{
    //Auto implemented properties

    class user_info
    {
    //    private int uid;
    //    private string uname;
    //    private DateTime doj;
        public int uid{get; set;}
        public string uname { get; set; }
        public DateTime doj { get; set; }
        public user_info(int a, string b, DateTime c)
        {
            uid = a;
            uname = b;
            doj = c;
        }


        //Read only permission   
        //pubic int UID {get; private set;}
        
    }
}
