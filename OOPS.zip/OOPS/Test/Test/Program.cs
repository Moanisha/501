﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Test
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the Number");
            int no; 
            no = int.Parse(Console.ReadLine());
            string[] arr = new string[no];
            DateTime[] darr = new DateTime[no];
            string[] format={"dd-MM-yyyy","dd-MMM-yyyy","dd/MM/YYYY","dd-MMMM-yyyy"};
            Console.WriteLine("Enter the date");
            for (int i = 0; i < no; i++)
            {
                arr[i] = Console.ReadLine();
            }
            DateTime[] dt=new DateTime[no];
            for(int i=0;i<no;i++)
            {
                if (DateTime.TryParseExact(arr[i], format, System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out dt[i]))
                {
                    Console.WriteLine((dt[i]).ToString("dd/MM/yyyy"));
                    
                }
                else
                {
                    Console.WriteLine("Invalid Input");
                }

            }

        }
    }
}
