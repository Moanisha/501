-- ========================================================================================================================
-- Author:		Manoranjith.G
-- Create date: 30-08-2017
-- Description:	Create CarRentalDatabaseAdo
-- ========================================================================================================================

CREATE DATABASE CarRentalDataBaseAdo;
EXEC sp_renamedb 'CarRentalDataBaseAdo' , 'CarRegistrationDataBase'; 

-- ========================================================================================================================
-- Author:		Manoranjith.G
-- Create date: 30-08-2017
-- Description:	Create Customer Registration Details Table
-- ========================================================================================================================

CREATE TABLE CustomerRegistrationDetails
(
	CustomerId        INT IDENTITY(1000,1)       not null,
	CustomerName      VARCHAR(40)                not null,
	EmailId           VARCHAR(40)                not null,
	PhoneNumber       BIGINT                     not null,
	CarBrand          VARCHAR(40)                not null,
	CarType           VARCHAR(30)                not null,
	CarPrice          VARCHAR(30)                not null,
	CONSTRAINT CustomerDetailPrimaryKey PRIMARY KEY(CustomerId) 
);

-- ========================================================================================================================
-- Author:		Manoranjith.G
-- Create date: 30-08-2017
-- Description:	Create Car Details Table which contains Brand name and Car Type
-- ========================================================================================================================

CREATE TABLE CarDetails
(
	CarBrand          NVARCHAR(40)              not null,
	CarType           NVARCHAR(30)              not null
	CONSTRAINT CarDetailPrimaryKey PRIMARY KEY(CarBrand,CarType),
);

-- ========================================================================================================================
-- Author:		Manoranjith.G
-- Create date: 30-08-2017
-- Description:	Create procedure for saving the Customer Registration details into the CustomerRegistrationDetails
-- ========================================================================================================================

ALTER PROCEDURE USP_InsertCustomerDetails(
	@CustomerName         VARCHAR(40),
	@EmailId              VARCHAR(40),
	@PhoneNumber          BIGINT,
	@CarBrand             VARCHAR(40),
	@CarType              VARCHAR(30),
	@CarPrice             VARCHAR(30),
	@SuccessResult        VARCHAR(20) OUT)        
AS
BEGIN TRY
	INSERT INTO CustomerRegistrationDetails (CustomerName,EmailId,PhoneNumber,CarBrand,CarType,CarPrice)
	VALUES(@CustomerName,@EmailId,@PhoneNumber,@CarBrand,@CarType,@CarPrice)
	DECLARE @SuccessCount INT;
	SET @SuccessCount=@@ROWCOUNT;
	IF(@SuccessCount=1)
	BEGIN
		SET @SuccessResult='SUCCESS'
	END
	ELSE
	BEGIN
		SET @SuccessResult='ERROR';
	END
END TRY
BEGIN CATCH
	SET @SuccessResult='EXCEPTION'
END CATCH;

-- ========================================================================================================================
-- Author:		Manoranjith.G
-- Create date: 30-08-2017
-- Description:	Create procedure for Populating Car Brand names in CarDetails Table
-- ========================================================================================================================

ALTER PROCEDURE USP_PopulatingCarBrandNames 
AS
BEGIN TRY
	SELECT DISTINCT CarBrand FROM CarDetails WITH(NOLOCK);
END TRY
BEGIN CATCH
	SELECT 'EXCEPTION'
END CATCH

-- ========================================================================================================================
-- Author:		Manoranjith.G
-- Create date: 30-08-2017
-- Description:	Create procedure for Populating Car type names for the corresponding CarBrand names in CarDetails tables
-- ========================================================================================================================

ALTER PROCEDURE USP_PopulatingCarTypeNames(@CarBrand VARCHAR(40)) 
AS
BEGIN TRY
	SELECT CarType FROM CarDetails WITH(NOLOCK) WHERE CarBrand=@CarBrand;
END TRY 
BEGIN CATCH
	SELECT 'EXCEPTION'
END CATCH

-- ========================================================================================================================
-- Author:		Manoranjith.G
-- Create date: 30-08-2017
-- Description: Display CarDetails Table	
-- ========================================================================================================================


SELECT CarBrand,CarType 
FROM CarDetails WITH(NOLOCK);

-- ========================================================================================================================
-- Author:		Manoranjith.G
-- Create date: 30-08-2017
-- Description: Display CustomerRegistrationDetails Table	
-- ========================================================================================================================

SELECT CustomerId,CustomerName,EmailId,PhoneNumber,CarBrand,CarType,CarPrice 
FROM CustomerRegistrationDetails WITH(NOLOCK);


DECLARE @s varchar(20)
EXEC USP_InsertCustomerDetails 'MNO','sds@gmai.com',1234567890,'Ford','Sedan','$45,000',@s out
PRINT @s;
EXEC USP_PopulatingCarBrandNames
