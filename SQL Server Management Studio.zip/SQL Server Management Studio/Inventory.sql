create database inventory;
create table suppliers(
	sid numeric(9,0) primary key,
	sname varchar(30),
	address varchar(40)
	);

create table parts(
	pid numeric(9,0) primary key,
	pname varchar(40),
	color varchar(15)
	);

create table catalog(
	sid numeric(9,0),
	pid numeric(9,0),
	cost numeric(10,2),
	primary key(sid,pid),
	foreign key(sid) references suppliers(sid),
	foreign key(pid) references parts(pid)
	);
insert into suppliers values(1,'Acme Widget Suppliers','1 Grub St., Potemkin Village, IL 61801');
insert into suppliers values(2,'Big Red Tool and Die','4 My Way, Bermuda Shorts, OR 90305');
insert into suppliers values(3,'Perfunctory Parts','99999 ShortPier,Terra Del Fuego,TX 41299');
insert into suppliers values(4,'Alien Aircaft Inc.','2 Groom Lake, Rachel, NV 51902');


insert into parts values(1,'Left Handed Bacon Stretcher Cover','Red');
insert into parts values(2,'Smoke Shifter End','Black');
insert into parts values(3,'Acme Widget Washer','Red');
insert into parts values(4,'Acme Widget Washer','Silver');
insert into parts values(5,'I Brake for Crop Circles Sticker','Translucent');
insert into parts values(6,'Anti-Gravity Turbine Generator','Cyan');
insert into parts values(7,'Anti-Gravity Turbine Generator','Magenta');
insert into parts values(8,'Fire Hydrant Cap','Red');
insert into parts values(9,'7 Segment Display','Green');



insert into catalog values(1,3,0.50);
insert into catalog values(1,4,0.50);
insert into catalog values(1,8,11.70);
insert into catalog values(2,3,0.55);
insert into catalog values(2,8,7.95);
insert into catalog values(2,1,16.50);
insert into catalog values(3,8,12.50);
insert into catalog values(3,9,1.00);
insert into catalog values(4,5,2.20);
insert into catalog values(4,6,1247548.23);
insert into catalog values(4,7,1247548.23);

select * from catalog;
select * from suppliers;
select * from parts;

--1. Find the pnames of parts for which there is some supplier.
    select distinct pname from parts join catalog 
	on parts.pid=catalog.pid;
  
--2. Find the snames of suppliers who supply every part.
    select pname,color,sname from suppliers join catalog
	on suppliers.sid=catalog.sid join parts
	on parts.pid=catalog.pid   

--3. Find the snames of suppliers who supply every red part.
    select pname,color,sname from suppliers join catalog
	on suppliers.sid=catalog.sid join parts
	on parts.pid=catalog.pid where color='red';

--4. Find the pnames of parts supplied by Acme Widget Suppliers and no one else.
     select pname
	 from parts 
	 where pid in(select pid
				from catalog join suppliers
				on suppliers.sid=catalog.sid
				where sname='Acme Widget Suppliers') ;  

--5. Find the sids of suppliers who charge more for some part than the average cost of that part (averaged over all the suppliers who supply that part).
    select avg(cost) from catalog group by pid;
    select sid,pid,cost 
	from catalog as a 
	where cost>(select avg(cost) 
	from catalog as b where a.pid = b.pid group by pid );


--6. For each part, find the sname of the supplier who charges the most for that part.
    select sname,sid_id.pid,max_cost 
	from suppliers join (select sid,max_tab.pid,max_cost 
	from catalog join (select pid,max(cost) as max_cost  
	from catalog group by pid) max_tab 
	on max_tab.pid=catalog.pid and cost=max_cost) sid_id 
	on sid_id.sid=suppliers.sid;

--7. Find the sids of suppliers who supply only red parts.
    select distinct sid from catalog join parts
	on catalog.pid=parts.pid
	where color='red'; 


--8. Find the sids of suppliers who supply a red part and a green part.
    select distinct sid from catalog join parts
	on catalog.pid=parts.pid
	where color='red' and color='green'; 



--9. Find the sids of suppliers who supply a red part or a green part.
    select distinct sid from catalog join parts
	on catalog.pid=parts.pid
	where color='red' or color='green'; 



--10. For every supplier that only supplies green parts, 
--    print the name of the supplier and the total number of parts that she supplies.
    select tab2.sid,color,sname,no_of_parts 
	from(select catalog.sid,color,sname from catalog 
	join parts on catalog.pid=parts.pid join suppliers 
	on suppliers.sid=catalog.sid where color='green') tab1
    join (select sid,count(pid) as no_of_parts from catalog where catalog.sid=(select catalog.sid from catalog 
	join parts on catalog.pid=parts.pid join suppliers 
	on suppliers.sid=catalog.sid where color='green')group by sid) tab2 on tab1.sid=tab2.sid where color='green' ; 

--11. For every supplier that supplies a green part and a red part, 
--    print the name and price of the most expensive part that she supplies











