
--Create a Database
create database chn17id001;

--Use the respective database for storing tables
use chn17id001;

--Get the current Date
select GETDATE();

--Creating and Deleting Schema
create schema Moanisha;
drop schema Moanisha;


--Drop Table
--drop table Moanisha.product;


alter table Product drop column Expirydate;								--Drop Column
alter table Product add Expirydate date;								--Add Column
sp_rename 'Product.Expirydate','Exp_date','column';						--Rename Column
alter table Product alter column Prod_name varchar(30);                 --Modify Column 


 drop table Customer;          
 drop table product;
 drop table supplier;
 

--create table
 
  create table product
(
	prod_id int identity(1,1),
	prod_name varchar(25) NOT NULL,
	mfg_date date,
	exp_date date,
	price numeric(5,2),
	company varchar(25),
	constraint prod_pk primary key(prod_id),
	constraint prod_mfg_check check(mfg_date<=getdate()),
	constraint prod_price_check check(price>0),
);



insert into product(prod_name,mfg_date,exp_date,price,company) values ('chocolate','2017-05-26','2017-12-15','520.01','itc');
insert into product(prod_name,mfg_date,exp_date,price,company) values ('biscuit','2016-05-26','2017-12-15','250','itc');
insert into product(prod_name,mfg_date,exp_date,price,company) values ('cake','2017-06-01','2017-06-30','520.01','ibacco');
insert into product(prod_name,mfg_date,exp_date,price,company) values ('mobile','2017-05-26','2020-12-15','999.01','redmi');
insert into product(prod_name,mfg_date,exp_date,price,company) values ('pc','2016-05-26','2020-12-15','999','lenovo');
insert into product(prod_name,mfg_date,exp_date,price,company) values ('medicine','2017-06-01','2017-12-30','420.01','pharma');
insert into product(prod_name,mfg_date,exp_date,price,company) values ('shirt','2017-06-01','2025-12-30','500','derby');




create table supplier
(
	supp_id int  identity(1,1),
	Supp_name varchar(20) not null,
	prod_id int,
	location varchar(20),
	constraint supp_pk primary key(supp_id),
	constraint supp_loc_check check(location in('chn','bge','hyd')),
	constraint sup_pid_fk foreign key(prod_id) references product(prod_id)
);


insert into supplier values('wsretail','1','chn');
insert into supplier values('infy','5','bge');
insert into supplier values('cloudtail','6','hyd');





create table customer
(
cust_id int identity(1,1),
cust_name varchar(25),
dob date,
blood_group varchar(20),
mobileno bigint,
addres varchar(200),
prod_id int,
qty int,
constraint cus_pk primary key(cust_id),
constraint cus_pid_fk foreign key(prod_id) references product(prod_id)
);

insert into customer values('vivek','1995-01-01','o+ve',9843608701,'bangalore',1,3);
insert into customer values('ganesh','1995-01-01','o+ve',9843608701,'bangalore',1,3);
insert into customer values('alex','1995-02-01','o+ve',9843608701,'chennai',2,4);
insert into customer values('lavanya','1994-11-25','a+ve',9843608701,'pune',5,2);
insert into customer values('moani','1994-05-01','ab+ve',9843608701,'chennai',6,3);
insert into customer values('sundar','1995-02-11','o-ve',9843608701,'coimbatore',7,3);
insert into customer values('dev','1995-12-10','o+ve',9843608701,'bangalore',4,1);
insert into customer values('netha','1995-11-13','o+ve',9843608701,'bangalore',1,4);
insert into customer values('mano','1995-12-10','ab+ve',9843608701,'coimbatore',4,2);
insert into customer values('vicky','1995-11-13','o-ve',9843608701,'chennai',1,4);
insert into customer values('moanisha','1995-10-13','b+ve',9843608701,null,1,4);
insert into customer values('moanisha','1994-01-13','b+ve',9843000701,'pune',null,4);



--Display all records from Customer Table
  select * from Customer;
--Display all supplier Details
  select * from supplier;
  select * from product;

--Display product name and price for all the products
  select prod_name,price from product;

--Display product id,mfg date and exipiry date
  select prod_id,mfg_date,exp_date from product;

--Display cust id,mobile no and addr 
  select cust_id,mobileno,addres from customer;


--Using where clause
--Display the biscuit product details
  select * from product where prod_name='biscuit';

--Display the customers who purchased more than 4 quantities
  select * from customer where qty>=4;
  
--Display the customer who belongs to Bangalore Address
  select * from customer where addres='bangalore'; 

--Display the customers who is not assigned with any address
  select * from customer where addres is null;

--Display the customers who provided address
  select * from customer where addres is not null;

--Display all customers who are banglore city o+ve customers
  select * from customer where addres='bangalore' and blood_group='o+ve';

--Display all products whose products belongs to itc and mfg date is after 2016   
  select * from product where company='itc' and mfg_date > '2016-12-31';

--Display the company name from the products table. Make sure company name is displayed once.
  select distinct company from product;

--Display prod name,price and company for all products.Change price to amount,company as vendor
  select prod_name,price as amount,company as vendor from product;
  select prod_name,price'amount',company'vendor' from product;

--Select a query to display product name,company,price and 10%deduction of the price
  select prod_name,company,price,price*10/100 as deduction from product;

--Display all customers who belongs to bangalore and pune
  select * from customer where addres='bangalore' or addres='pune';
  select * from customer where addres in('bangalore','pune','coimbatore');

--Display the product details like biscuit,cake and mobile
  select * from product where prod_name in('biscuit','cake','mobile');

--Display the supplier details who supply the products of 5 and 6
  select * from supplier where prod_id in(5,6);

--Display the customers whose quantity withing the range of 2 to 4
  select * from customer where qty between 2 and 4;

--Display all products who are having 5 letter company name
  select * from product where company like '_____';

--Display all products who are having 5 letter company name starting with r
  select * from product where company like 'r____';

--Display the customers whose name starts with m
  select * from customer where cust_name like 'm%';

--Display all customers who are having second letter a
  select * from customer where cust_name like '_a%';

--Display all customers whose last before letter contains e
  select * from customer where cust_name like '%e_';

--Display all customers who has a in their name
  select * from customer where cust_name like '%a%';

--Display all products in asc order of product names
  select * from product order by prod_name;
  select * from product order by prod_name desc;

--Display all details of customer asc order of quantity and name in desc 
  select * from customer order by qty,cust_name desc;

--Display prodname,price,custname,total amount customer is paying-THETA
  select prod_name,price,cust_name,price*qty as total from product,customer where product.prod_id=customer.prod_id;

--ANSI SQL
  select prod_name,price,cust_name,price*qty as total from product join customer on product.prod_id=customer.prod_id;

--Display the prodid,prodname,supplier id,supplier name and location
  select supplier.prod_id,prod_name,supp_id,Supp_name,location from product join supplier on product.prod_id=supplier.prod_id;

--Display cust id,cust name,prod name and price where the customer belongs to chennai and cbe 
  select cust_id,cust_name,prod_name,price 
  from customer join product 
  on product.prod_id=customer.prod_id 
  where addres in('chennai','coimbatore');

--               [OR]

  select cust_id,cust_name,prod_name,price 
  from customer join product 
  on product.prod_id=customer.prod_id 
  and addres in('chennai','coimbatore');

--Display the prodid and prodname ,custid and custname,supp id and supp name

  select product.prod_id,prod_name,cust_id,cust_name,supp_id,supp_name 
  from product join customer
  on product.prod_id=customer.prod_id
  join supplier
  on supplier.prod_id=product.prod_id;

--Display the customer id,customer name,supplier name and the location 

 select cust_id,cust_name,Supp_name,location 
 from customer join supplier
 on supplier.prod_id=customer.prod_id;

--Create table Product grade
  create table product_grade
  (
   grade char(1),
   minprice numeric(5),
   maxprice numeric(5),
   tolerance numeric(5,3)
  );

  select * from product_grade;

--Display the prodid,prodname,price,company and grade of the product
  select prod_id,prod_name,price,company,grade 
  from product,product_grade 
  where price between minprice and maxprice; 


create table employee
 (
emp_id int,
emp_name varchar(25),
city varchar(15),
designation varchar(10),
manager_id int,
sal numeric(7,2) 
 );
 
 select * from employee; 

--Self join
--Display empid,emp name,designation,sal and manager name of all employee
 select b.emp_id,b.emp_name,b.designation,b.sal,a.emp_name as managername 
 from employee a join employee b
 on b.manager_id = a.emp_id


--Display prodid,prodname,custid,custname    CROSS JOIN-THETA MODEL
  select product.prod_id,prod_name,cust_id,cust_name from product,customer;

--CROSS JOIN-ANSI
  select product.prod_id,prod_name,cust_id,cust_name from product cross join customer;

--Natural join
  select * from product,customer where product.prod_id=customer.prod_id;
  select * from product join customer on product.prod_id=customer.prod_id;
--Select * from product natural join customer; Not supported in sql server


--Display custname,product name for the customers
  select cust_name,prod_name from customer left outer join product on product.prod_id=customer.prod_id;
  select cust_name,prod_name from product right outer join customer on product.prod_id=customer.prod_id;
  select cust_name,prod_name from product full outer join customer on product.prod_id=customer.prod_id;

--Display the highest price in the product table
  select max(price) from product; 

--Display the lowest price
  select min(price) from product;

--How many no of customers in cust table
  select count(cust_id) from customer;

  select count(addres) from customer; --Ignores null value

--How many no of unique address 
  select count(distinct addres) from customer;

--Sum of price in product table
  select sum(price) from product;

--Average of price in the product table
  select avg(price) from product;
  select * from product;
  select avg(price) from product; --Excludes null

--Display price from product
  select price from product
  order by price;

  select avg(ISNULL(price,0)) from product;

  select * from customer;

--Group by
--Display blood group and no of customers in each blood group
  select blood_group,count(cust_id) 
  from customer
  group by blood_group;

--Display no of customers comes in each address
  select addres,count(cust_id)
  from customer
  group by addres;

--Display the no of customers in each address who have purchased more than 2 quantities
  select addres,count(cust_id)
  from customer
  where qty>2
  group by addres;

--Write a query to display the number of customers available based on the year of dob
  select year(dob),count(cust_id)
  from customer
  group by year(dob);

--Year wise each blood group how many people
  select year(dob),blood_group,count(cust_id)
  from customer
  group by year(dob),blood_group
  order by year(dob);

--Display address wise each product purchased 
  select addres,count(prod_id)
  from customer
  group by addres;

--Display the prod id and how many no of people purchased the prod
  select prod_id,count(prod_id)
  from customer
  group by prod_id;

--Display the product name and the no of people purchased the product
  select prod_name,count(cust_id)
  from product join customer
  on customer.prod_id=product.prod_id
  group by prod_name;

--Display the customer name and the no of products he purchased
  select cust_name,count(prod_id)
  from customer
  group by cust_name;

--Display the product name and the no of people purchased the products and who 
--have purchased more than 2 products
  select prod_name,count(cust_id)
  from product join customer
  on  customer.prod_id=product.prod_id
  group by prod_name
  having count(cust_id)>=2;

--Display the supplier name ,prod name and how many no of customers purchased the product
  select supp_name,prod_name,count(cust_id)
  from supplier join product
  on  supplier.prod_id=product.prod_id join customer
  on  customer.prod_id=product.prod_id 
  group by Supp_name,prod_name;

--Display all the customers who are coming in the same address where Mr.Alex comes
  select * from customer where addres in (select addres from customer where cust_name='alex');

--Display all customers who have purchased same quantities as Mr.Mano purchased
  select * from customer where qty =(select qty from customer where cust_name='mano');
  
--Display all customers who have same blood group as Mr.Dev
  select * from customer where blood_group=(select blood_group from customer where cust_name='dev')and cust_name!='dev';
  
--Display all products which was produced in the same year of mobile
  select * from product where year(mfg_date)=(select YEAR(mfg_date) from product where prod_name='mobile');

--Display the highest price product details 
  select * from product where price in(select max(price) from product);

--Write a query to display the second highest product details
   select * from product 
   where price in
   (select max(price) from product 
   where price not in 
   (select max(price) from product));

   select top 2 * from product order by price desc;

--Display all products who are having more than the price of where Cloudtail who supply the products
   select * from product 
   where price>
   (select price from supplier join product on supplier.prod_id=product.prod_id 
   where Supp_name='cloudtail');

   select * from product where price >
   (select price from product 
   where prod_id=(
   select prod_id from supplier where 
   Supp_name='cloudtail'));

--Display all products who are having more than the price of product id 8
   select * from product where price >(select price from product where prod_id = 8);

--Display all products who are having more than the price of biscuit along with the products manufactured in the year of cake
   select * from product 
   where price >
   (select price from product where prod_name='biscuit') 
   and year(mfg_date)=
   (select year(mfg_date) from product where prod_name='cake');

--Display all products which was purchased by more than 4 customers
   select * from customer
   select * from product

   select * from product
   where prod_id=(select prod_id from customer
   group by prod_id
   having count(prod_id)>=3);

--Display all products which was purchased 3 or more quantities
   select * from product where prod_id in (select prod_id from customer where qty>=3);

--Display all products which are more than the price of itc company
  select * from product where price in(select price from product where company='itc'); --It displays price equal to itc 
  select * from product where price >(select max(price) from product where company='itc');
  select * from product where price >all(select price from product where company='itc');
  
--Display all products which are less than any one price of itc company  
  select * from product where price <any(select price from product where company='itc');

--Display all products which is greater than the price of any itc product
  select * from product where price >any(select price from product where company='itc');

--Display all products whose price is more than the all products average price
  select *  from product where price >(select avg(price) from product);

--Display all employees who are getting more than the salary of all employees average sal
  select * from employee;
  select * from employee where sal >(select avg(sal) from employee);

--Display all emp who are getting more than or equal to their departments avg sal
  select * 
  from employee as e 
  where e.sal>=(select avg(sal) 
				from employee 
				where designation=e.designation);

--Display all emp highest salary getter in each city
  select *
  from employee as e
  where e.sal=( select max(sal) 
                from employee		
				where city=e.city);

--Display all customers who bought max quantity in each product
  select * 
  from customer as c 
  where c.qty =(select max(qty) 
				from customer 
				where prod_id=c.prod_id);

--Display server name
  select @@SERVERNAME

--**********************************VIEW********************************************************

create view vname as
(select prod_id,prod_name,price 
from product);

select * from vname;

--Create a view that Display the prod name,supp name and price
  create view v2 as
  (select prod_name,supp_name,price
  from product join supplier
  on product.prod_id=supplier.prod_id);

  select * from v2;

  sp_helptext 'dbo.v2';

  alter view v2 with encryption as
  (select prod_name,supp_name,price
  from product join supplier
  on product.prod_id=supplier.prod_id);

  select * from sys.objects;

  select * into duplicate from product;
  select * from duplicate;
  drop table duplicate;

--To create a duplicate table only with structure and not the values
  select * into duplicate from product where 1=2;
  select * from duplicate;

  create view vname with schemabinding as
  (select prod_id,prod_name,price 
  from dbo.duplicate);

  drop view vname;  

  
alter TRIGGER trig
ON duplicate 
instead of insert, UPDATE, DELETE 
AS PRINT ('You made one DML operation'); 

insert into duplicate values('newproduct','2016-05-26','2018-05-26',100.00,'abc');

select * from duplicate;

delete from duplicate where prod_id=8;


CREATE TABLE [dbo].[userdata](
[userid] [int] NOT NULL,
[pwd] [varchar](25) NULL,
[Status] [varchar](50) NULL,
[Remarks] [varchar](100) NULL,
 CONSTRAINT [PK_userdata] PRIMARY KEY CLUSTERED 
(
[userid] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
 
GO
SET ANSI_PADDING OFF
GO
INSERT [dbo].[userdata] ([userid], [pwd], [Status], [Remarks]) VALUES (1, N'ABC', NULL, N'Not Suitable')
INSERT [dbo].[userdata] ([userid], [pwd], [Status], [Remarks]) VALUES (2, N'DEF', N'Rejected', N'No Facility')
INSERT [dbo].[userdata] ([userid], [pwd], [Status], [Remarks]) VALUES (3, N'GHI', N'3', N'No Profit Margin')
INSERT [dbo].[userdata] ([userid], [pwd], [Status], [Remarks]) VALUES (4, N'JKL', N'Rejected', N'No Profit Margin')
INSERT [dbo].[userdata] ([userid], [pwd], [Status], [Remarks]) VALUES (5, N'MNO', N'Requested', NULL)
INSERT [dbo].[userdata] ([userid], [pwd], [Status], [Remarks]) VALUES (6, N'PQR', N'Requested', NULL)
INSERT [dbo].[userdata] ([userid], [pwd], [Status], [Remarks]) VALUES (7, N'STU', N'Requested', NULL)
INSERT [dbo].[userdata] ([userid], [pwd], [Status], [Remarks]) VALUES (8, N'VWX', N'Requested', NULL)
INSERT [dbo].[userdata] ([userid], [pwd], [Status], [Remarks]) VALUES (9, N'XYZ', N'Requested', NULL)
INSERT [dbo].[userdata] ([userid], [pwd], [Status], [Remarks]) VALUES (10, N'AAA', N'Requested', NULL)
INSERT [dbo].[userdata] ([userid], [pwd], [Status], [Remarks]) VALUES (11, N'BBB', N'Rejected', N'Not useful')
INSERT [dbo].[userdata] ([userid], [pwd], [Status], [Remarks]) VALUES (12, N'CCC', N'Accepted', N'Approved')
INSERT [dbo].[userdata] ([userid], [pwd], [Status], [Remarks]) VALUES (13, N'DDD', N'Requested', NULL)
INSERT [dbo].[userdata] ([userid], [pwd], [Status], [Remarks]) VALUES (14, N'EEE', N'Requested', NULL)
INSERT [dbo].[userdata] ([userid], [pwd], [Status], [Remarks]) VALUES (15, N'FFF', N'Requested', NULL)

select * from userdata;
 