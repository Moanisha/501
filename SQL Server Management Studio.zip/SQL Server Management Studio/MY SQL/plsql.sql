--********************************PL/SQL**********************************

--Display varchar output

  declare @name varchar(20);
  set @name='Moanisha';
--select @name;
  print 'The name is '+@name;

  
--Display int output
  declare @age int;
  set @age=25;
  print +@age;
  print 'The age is'+cast(@age as varchar(10));

  begin
  declare @pname varchar(20);
  select @pname=prod_name from product where prod_id=1;
  print 'The product name is :'+@pname;
  end

--Display the product name and the price of the product for the product id 3 
  begin
  declare @prod_name varchar(20);
  declare @price numeric(5,2);
  select @prod_name=prod_name,@price=price from product where prod_id=3;
  print 'The product name is :' +@prod_name;
  print 'The price is :'+cast(@price as varchar(10));
  end

--Display the price of the cake and the category of the cake >500 high cost <500 low cost
  begin
  declare @price numeric(5,2);
  select @price=price from product where prod_name='cake';
  if (@price>500)
     begin
	   print 'The product price is :'+cast(@price as varchar(10))+'And the category is high cost';
	 end
  else
     print 'The product price is :'+cast(@price as varchar(10))+'And the category is low cost';
  end

  --*******************************STORED PROCEDURE*******************************************
--Creating procedure
  create procedure pro_name as
  select * from product; 

--Call procedure
  exec pro_name;

--Alter procedure
  alter procedure pro_name as
  select prod_id,prod_name from product; 

--Display all emp who are clerk
  create procedure dis_clerk as
  select * from employee where designation='clerk';
  exec dis_clerk;

--Modify to display all the secretary
  alter procedure dis_clerk as
  select * from employee where designation='secretary';
  exec dis_clerk;

  create procedure prc3 (@job varchar(20)) as
  select * from employee where designation=@job;
  exec prc3 'secretary';
  exec prc3 'analyst';
  exec prc3 'clerk';
  exec prc3 'president';

--Display all customer which is greater than the specific quantity supplied at run time
  create procedure prc4 (@qty int) as
  select * from customer where qty>@qty;
  exec prc4 3;

--Display the employees who are getting highest sal in the given city where the city at run time
  create procedure prc5 (@city varchar(10)) as
  select * from employee where sal=(select max(sal) from employee where city=@city);
  select * from employee;
  exec prc5 'che';

--Display supp id,supp name,prod id,prod name for the products which was supplied by supplier
  create procedure prc6 as
  select supp_id,supp_name,product.prod_id,prod_name 
  from supplier join product 
  on product.prod_id=supplier.prod_id;
  exec prc6;

--Accept the prod id at run time. Display the name,prod price . If the price is >500 display high cost else low cost
 
  alter procedure pr7(@pr_id int) as
  if(@pr_id=(select prod_id from product where prod_id=@pr_id))
  begin
  declare @pr numeric(5,2)
  declare @pnam varchar(20)
  select @pnam=prod_name,@pr=price from product where prod_id=@pr_id; 
  if(@pr>500)
    print 'The product name is:'+@pnam+'The Price :'+cast(@pr as varchar(10))+'And the category is high cost';
  else
    print 'The product name is:'+@pnam+'The Price :'+cast(@pr as varchar(10))+'And the category is low cost';
  end
  else
    print 'No id';

 
 exec pr7 1;

--Allow user to insert supplier details by accepting supplier table values at run time
  alter procedure pr8(@sname varchar(20),@pid int,@location varchar(15)) as
  insert into supplier (Supp_name,prod_id,location) values(@sname,@pid,@location);
  exec pr8 'Cadbury',1,'chn';

  select * from supplier;

--
  alter procedure add1(@m1 int,@m2 int,@tot int out) as
  set @tot=@m1+@m2;
  
  
  declare @res int;
  exec add1 5,7,@res output;
  print @res;

  select * from product;
  select * from supplier;
  select * from customer;

--Display the prod id,prod name,price,no of cust purchased the product 
  select product.prod_id,prod_name,price,count(cust_id) 
  from product join customer
  on product.prod_id=customer.prod_id
  group by product.prod_id,prod_name,price; 

--Derived Table
--Display the company name,no of prod produced by the company,no of customers who purchased the company's product
  
  select tab1.company,tab1.total_prod,tab2.total_cust 
  from
  (select company,count(product.prod_id) total_prod
  from product
  group by company) tab1
  join
  (select company,count(cust_id) total_cust 
  from customer c join product p
  on c.prod_id=p.prod_id
  group by company) tab2
  on tab1.company = tab2.company;

  --Display the customer id,cust name ,prod name,price of product, no of cust purchased the product 
   select tab1.cust_id,tab1.cust_name,tab1.prod_name,tab1.price,tab2.cnt
   from
   (select cust_id,cust_name,prod_name,product.prod_id,price from
   customer join product
   on customer.prod_id=product.prod_id) tab1
   join
   (select prod_id,count(cust_id) as cnt
   from customer
   group by prod_id) tab2
   on tab1.prod_id=tab2.prod_id;


 --***************************************(OR)*****************************

   select cust_id,cust_name,prod_name,price,tab3.totcust 
   from customer join product
   on customer.prod_id=product.prod_id
   join
   (select prod_id,count(cust_id) as totcust from customer group by prod_id) tab3
   on tab3.prod_id=product.prod_id;


  