create database Task1;
create table branch
(
branchno char(4),
street varchar(25) not null,
city varchar(15) not null,
postcode varchar(8) not null,
constraint branch_pk primary key(branchno)
);
create table staff
(
staffno varchar(5),
fname varchar(15) not null,
lname varchar(15) not null,
oposition varchar(10) not null,
sex char(1),
DOB date,
salary decimal(9,2) not null,
branchno char(4) not null,
constraint stf_pk primary key(staffno),
constraint stf_branch_fk foreign key(branchno) references branch(branchno)  
);

create table client
(
clientno varchar(7),
fname varchar(15) not null,
lname varchar(15) not null,
telno varchar(13) not null,
preftype varchar(10) not null,
maxrent decimal(5,1) not null,
constraint cl_pk primary key(clientno)
);

create table privateowner
(
ownerno varchar(7),
fname varchar(15) not null,
lname varchar(15) not null,
address varchar(50)not null,
telno varchar(13) not null
constraint po_pk primary key(ownerno)
);

create table registration
(
clientno varchar(7),
branchno char(4),
staffno varchar(5) not null,
datejoined date not null,
constraint reg_pk primary key(clientno,branchno),
constraint reg_sno_fk foreign key(staffno) references staff(staffno)  
);


create table viewing
(
clientno varchar(7),
propertyno varchar(8),
viewdate date not null,
comments varchar(50),
constraint view_pk primary key(clientno,propertyno) 
);
create table propertyforrent
(
propertyno varchar(8),
street varchar(25) not null,
city varchar(15) not null,
postcode varchar(8) not null,
propertytype varchar(10) not null,
rooms smallint not null,
rent decimal(5,1) not null,
ownerno varchar(7) not null,
staffno varchar(5),
branchno char(4) not null,
constraint pf_pk primary key(propertyno),
constraint pf_on_fk foreign key(ownerno) references privateowner(ownerno),  
constraint pf_sn_fk foreign key(staffno) references staff(staffno),  
constraint pf_bn_fk foreign key(branchno) references branch(branchno)  
);
--data entry

INSERT [dbo].[Branch] ([branchNo], [street], [city], [postcode]) VALUES (N'B002      ', N'56 Clover Dr', N'London    ', N'NW10 6EU  ')
GO
INSERT [dbo].[Branch] ([branchNo], [street], [city], [postcode]) VALUES (N'B003      ', N'163 Main St', N'Glasgow   ', N'G11 9QX   ')
GO
INSERT [dbo].[Branch] ([branchNo], [street], [city], [postcode]) VALUES (N'B004      ', N'32 Manse Rd', N'Bristol   ', N'BS99 1NZ  ')
GO
INSERT [dbo].[Branch] ([branchNo], [street], [city], [postcode]) VALUES (N'B005      ', N'22 Deer RD', N'London    ', N'SW1 4EH   ')
GO
INSERT [dbo].[Branch] ([branchNo], [street], [city], [postcode]) VALUES (N'B007      ', N'16 Argyll St', N'Aberdeen  ', N'AB2 3SU   ')
GO
INSERT [dbo].[Branch] ([branchNo], [street], [city], [postcode]) VALUES (N'B015      ', N'16 Argyll St', N'Aberdeen  ', N'AB2 3SU   ')
GO
----------------------------------------------------------------------------------

INSERT [dbo].[Client] ([clientNo], [fName], [lName], [telNo], [prefType], [maxRent]) VALUES (N'CR56      ', N'Aline     ', N'Stewart   ', N'0141-848-1825       ', N'Flat      ', 350)
GO
INSERT [dbo].[Client] ([clientNo], [fName], [lName], [telNo], [prefType], [maxRent]) VALUES (N'CR62      ', N'Mary      ', N'Tregear   ', N'01224-196720        ', N'Flat      ', 600)
GO
INSERT [dbo].[Client] ([clientNo], [fName], [lName], [telNo], [prefType], [maxRent]) VALUES (N'CR74      ', N'Mike      ', N'Ritchie   ', N'01475-392178        ', N'House     ', 750)
GO
INSERT [dbo].[Client] ([clientNo], [fName], [lName], [telNo], [prefType], [maxRent]) VALUES (N'CR76      ', N'John      ', N'Kay       ', N'0207-774-5632       ', N'Flat      ', 425)
GO

------------------------------------------------------------------------------------------------------------

INSERT [dbo].[PrivateOwner] ([ownerNo], [fName], [lName], [address], [telNo]) VALUES (N'CO40      ', N'Tina      ', N'Murphy    ', N'63 Well St, Glasgow G42', N'0141-943-1728       ')
GO
INSERT [dbo].[PrivateOwner] ([ownerNo], [fName], [lName], [address], [telNo]) VALUES (N'CO46      ', N'Joe       ', N'Keogh     ', N'2 Fergus Dr, Aberdeen AB2 7SX', N'01224-861212        ')
GO
INSERT [dbo].[PrivateOwner] ([ownerNo], [fName], [lName], [address], [telNo]) VALUES (N'CO87      ', N'Carol     ', N'Farrel    ', N'6 Achray St, Glasgow G32 9DX', N'0141-357-7419       ')
GO
INSERT [dbo].[PrivateOwner] ([ownerNo], [fName], [lName], [address], [telNo]) VALUES (N'CO93      ', N'Tony      ', N'Shaw      ', N'12 Park P, Glasgow G4 0QR', N'0141-225-7025       ')
GO

------------------------------------------------------------------------------------------------------

INSERT [dbo].[PropertyForRent] ([propertyNo], [street], [city], [postcode], [propertytype], [rooms], [rent], [ownerNo], [staffNo], [branchNo]) VALUES (N'PA14      ', N'16 Holhead', N'Aberdeen  ', N'AB7 5SU   ', N'House     ', 6, 650, N'CO46      ', N'SA9       ', N'B007      ')
GO
INSERT [dbo].[PropertyForRent] ([propertyNo], [street], [city], [postcode], [propertytype], [rooms], [rent], [ownerNo], [staffNo], [branchNo]) VALUES (N'PL94      ', N'6 Argyll St', N'London    ', N'NW2       ', N'Flat      ', 4, 400, N'CO87      ', N'SL41      ', N'B005      ')
GO
INSERT [dbo].[PropertyForRent] ([propertyNo], [street], [city], [postcode], [propertytype], [rooms], [rent], [ownerNo], [staffNo], [branchNo]) VALUES (N'PG4       ', N'6 Lawrence St', N'Glasgow   ', N'G11 9QX   ', N'Flat      ', 3, 350, N'CO40      ', NULL, N'B003      ')
GO
INSERT [dbo].[PropertyForRent] ([propertyNo], [street], [city], [postcode], [propertytype], [rooms], [rent], [ownerNo], [staffNo], [branchNo]) VALUES (N'PG36      ', N'2 Manor Rd', N'Glasgow   ', N'G32 4QX   ', N'Flat      ', 3, 375, N'CO93      ', N'SG37      ', N'B003      ')
GO
INSERT [dbo].[PropertyForRent] ([propertyNo], [street], [city], [postcode], [propertytype], [rooms], [rent], [ownerNo], [staffNo], [branchNo]) VALUES (N'PG21      ', N'18 Dale Rd', N'Glasgow   ', N'G12       ', N'House     ', 5, 600, N'CO87      ', N'SG37      ', N'B003      ')
GO
INSERT [dbo].[PropertyForRent] ([propertyNo], [street], [city], [postcode], [propertytype], [rooms], [rent], [ownerNo], [staffNo], [branchNo]) VALUES (N'PG16      ', N'5 Novar Dr', N'Glasgow   ', N'G12 0Ax   ', N'Flat      ', 4, 450, N'CO93      ', N'SG14      ', N'B003      ')
GO

-------------------------------------------------------------------------------------------------------

INSERT [dbo].[Staff] ([staffNo], [fName], [lName], [oposition], [sex], [DOB], [salary], [branchNo]) VALUES (N'SA9       ', N'MAry      ', N'Howe      ', N'Assistant ', N'F', CAST(N'1970-02-10' AS Date), 9000, N'B007      ')
GO
INSERT [dbo].[Staff] ([staffNo], [fName], [lName], [oposition], [sex], [DOB], [salary], [branchNo]) VALUES (N'SG14      ', N'David     ', N'Ford      ', N'Supervisor', N'M', CAST(N'1958-03-24' AS Date), 18000, N'B003      ')
GO
INSERT [dbo].[Staff] ([staffNo], [fName], [lName], [oposition], [sex], [DOB], [salary], [branchNo]) VALUES (N'SG37      ', N'Ann       ', N'Beech     ', N'Assistant ', N'F', CAST(N'1960-11-10' AS Date), 12000, N'B003      ')
GO
INSERT [dbo].[Staff] ([staffNo], [fName], [lName], [oposition], [sex], [DOB], [salary], [branchNo]) VALUES (N'SG5       ', N'Susan     ', N'Brand     ', N'Manager   ', N'F', CAST(N'1940-06-03' AS Date), 24000, N'B003      ')
GO
INSERT [dbo].[Staff] ([staffNo], [fName], [lName], [oposition], [sex], [DOB], [salary], [branchNo]) VALUES (N'SL21      ', N'John      ', N'White     ', N'Manager   ', N'M', CAST(N'1945-10-01' AS Date), 30000, N'B005      ')
GO
INSERT [dbo].[Staff] ([staffNo], [fName], [lName], [oposition], [sex], [DOB], [salary], [branchNo]) VALUES (N'SL41      ', N'Julie     ', N'Lee       ', N'Assistant ', N'F', CAST(N'1965-06-13' AS Date), 9000, N'B005      ')
GO

---------------------------------------------------------------------------------------------------------

INSERT [dbo].[Viewing] ([clientNo], [propertyNo], [viewDate], [comments]) VALUES (N'CR56      ', N'PA14      ', CAST(N'2004-05-24' AS Date), N'too small')
GO
INSERT [dbo].[Viewing] ([clientNo], [propertyNo], [viewDate], [comments]) VALUES (N'CR76      ', N'PG4       ', CAST(N'2004-04-20' AS Date), N'too remote')
GO
INSERT [dbo].[Viewing] ([clientNo], [propertyNo], [viewDate], [comments]) VALUES (N'CR56      ', N'PG4       ', CAST(N'2004-05-26' AS Date), N'')
GO
INSERT [dbo].[Viewing] ([clientNo], [propertyNo], [viewDate], [comments]) VALUES (N'CR62      ', N'PA14      ', CAST(N'2004-05-14' AS Date), N'no dining room')
GO
INSERT [dbo].[Viewing] ([clientNo], [propertyNo], [viewDate], [comments]) VALUES (N'CR56      ', N'PG36      ', CAST(N'2004-04-28' AS Date), NULL)
GO

--------------------------------------------------------------------------------------------------
INSERT INTO Registration VALUES ('CR76', 'B005', 'SL41', '2001-01-02');
INSERT INTO Registration VALUES ('CR56', 'B003', 'SG37', '2000-04-11');
INSERT INTO Registration VALUES ('CR74', 'B003', 'SG37', '1999-11-16');
INSERT INTO Registration VALUES ('CR62', 'B007', 'SA9',  '2000-03-07');
SELECT * FROM registration;
select * from branch;
--1
select * from staff;

--2
select staffno,fname,lname,salary from staff;

--3
select propertyno from viewing;

--4
select staffno,fname,lname,salary,salary*12 as yearly_salary from staff;

--5
select * from staff where salary>10000;

--6
select * from branch where city in ('London','Glasgow'); 

--7
select * from staff where salary between 20000 and 30000;

--8
select * from staff where oposition in('supervisor','manager');

--9
select * from privateowner where address like '%Glasgow%';

--10
select * from viewing where comments = ' ';

--11
select salary from staff order by salary desc;

--12 
select * from propertyforrent order by propertytype;


 --*******************************JOINS****************************************

 --1
 select fname,lname 
 from client join viewing 
 on client.clientno=viewing.clientno
 where comments !='';

 --2
 select branch.branchno,staff.staffno,fname,lname,propertytype
 from branch left outer join staff
 on branch.branchno = staff.branchno
 left outer join propertyforrent
 on staff.staffno=propertyforrent.staffno;

 --3
 select branch.branchno,staff.staffno,fname,lname,propertytype,branch.city
 from branch left outer join staff
 on branch.branchno = staff.branchno
 left outer join propertyforrent
 on staff.staffno=propertyforrent.staffno;

 --4
 select staff.staffno,fname,lname,COUNT(propertyforrent.staffno)
 from staff left outer join propertyforrent
 on staff.staffno=propertyforrent.staffno
 group by staff.staffno,fname,lname;


 --5
 select branch.branchno
 from branch join propertyforrent
 on branch.city=propertyforrent.city;

 --6
 select propertyforrent.propertyno
 from branch right outer join propertyforrent
 on branch.city=propertyforrent.city;

 --7
 select branch.branchno,propertyno
 from branch full outer join propertyforrent
 on branch.city=propertyforrent.city;



--***************************************AGGREGATE*******************************************

--1)Find the minimum, maximum, and average staff salary
  select min(salary),max(salary),avg(salary) from staff;

--2)How many properties cost more than 350 per month to rent?
  select * from propertyforrent;
  select COUNT(propertyno) from propertyforrent where rent>350.0;

--3)How many different properties were viewed in May 2004?
  select * from viewing;
  select count(propertyno) from viewing where viewdate between '2004-05-01' and '2004-05-31';
  
--4)Find the total number of Managers and the sum of their salaries
  select * from  staff;
  select * from branch;
  select count(oposition),sum(salary) from staff where oposition='Manager'; 

--5)Find the number of staff working in each branch and the sum of their salaries.
  select branch.branchno,count(staffno),sum(salary) from staff right outer join branch
  on staff.branchno = branch.branchno
  group by branch.branchno;

--6)For each branch office with more than one member of staff, find the number of staff 
--working in each branch and the sum of their salaries.
  
   select branch.branchno,count(staffno),sum(salary) from staff right outer join branch
  on staff.branchno = branch.branchno
  group by branch.branchno
  having count(staffno)>1;


  --*************************************SUB QUERY**********************************

  --1)List the staff who work in the branch at �163 Main St�.

   select staffno,fname,lname from staff
   where branchno=(select branchno from branch where street='163 Main st');


   --2. List all staff whose salary is greater than the average salary, 
   --and show by how much their salary is greater than the average.
   select staffno,(salary-(select avg(salary) from staff)) as g from staff
   where salary>(select avg(salary) from staff);

   --3.List the properties that are handled by staff who work in the branch at �163 Main St�.

 
  select propertyno from propertyforrent
  where staffno in ( select staffno from staff
   where branchno = (select branchno from branch where street='163 Main st'));

   --4.Find all staff whose salary is larger than the salary
   -- of at least one member of staff at branch B003.
select staffno from staff
where salary >(select min(salary) from staff where branchno='B003');


--5.Find all staff whose salary is larger than the salary of every member of staff at branch B003.

select staffno from staff
where salary >(select max(salary) from staff where branchno='B003');

--6.Find all staff who work in a London branch office. (Try with Exists/Not Exists Operator).


where branchno in(select branchno from branch where city='london' );



--*******************************************DML************************************************************


--1. Insert a new row into the Staff table supplying data for all columns.
     insert into staff values(N'SL45      ', N'Jimmy     ', N'Karter       ', N'Assistant ', N'M', CAST(N'1965-06-13' AS Date), 9000, N'B005      ');
--2. Insert a new row into the Staff table supplying data for all mandatory columns:             staffNo, fName, lName, position, salary, and branchNo.
	 insert into staff (staffNo, fName, lName, oposition, salary,branchNo)values(N'SA8     ', N'Jimmy     ', N'Karter       ', N'Assistant ',9000, N'B007     ');
--3. Give all staff a 3% pay increase.
     UPDATE staff
     SET salary = salary+(salary*0.03);
--4. Give all Managers a 5% pay increase.
     UPDATE staff
     SET salary = salary+(salary*0.05)
	 where oposition='manager';
--5. Promote David Ford (staffNo = �SG14�) to Manager and change his salary to 18,000.
     update staff
	 set oposition='Manager',salary=18000
	 where staffNo='SG14';
--6. Delete all viewings that relate to property PG4.
     select * from viewing;
	 delete from viewing where propertyno='PG4';
--7. Delete all rows from the Viewing table.
     truncate table viewing;


--*********************************************VIEW*******************************************************
--1. Create a view so that the manager at branch B003 can see only the details for staff
--   who work in his or her branch office.
     select * from staff;
     create view v1 as
	 select * from staff 
	 where branchno='B003' AND oposition!='manager';

--2. Create a view of the staff details at branch B003 that excludes salary information, 
--  so that only managers can access the salary details for staff who work at their branch.
     alter view v1 as
	 select staffno,fname,lname,salary from staff 
	 where branchno='B003' AND oposition!='manager';



--3. Create a view of staff who manage properties for rent, 
--which includes the branch number they work at, their staff number, and the number of properties they manage 
     create view v2 as
	 select distinct branchno,tab1.staffno,tab1.cnt from propertyforrent 
	 join
	 (select staffno,count(propertytype) as cnt 
	 from propertyforrent 
	 group by staffno )tab1
	 on tab1.staffno=propertyforrent.staffno;


--****************************************STORED PROCEDURE***************************************************
--1. Create a stored procedure named sp_disp_staff to display staffno, fname, DOB, salary for all the staff.
  create procedure sp_disp_staff as
  select staffno,fname,DOB,salary 
  from staff;

  exec sp_disp_staff;

--2. Create a stored procedure named sp_disp_client_property to list the client fname,
-- telephone no, maxrent, property type, street, room and rent details for the corresponding property
  
   exec sp_disp_client_property;
   create procedure sp_disp_client_property as
   select fname,telno,maxrent,preftype,tab.street,tab.rooms,tab.rent 
   from client 
   join
   (select clientno,street,rooms,rent 
   from propertyforrent join viewing
   on viewing.propertyno=propertyforrent.propertyno
   where propertyforrent.propertyno in(
   select propertyno
   from client join viewing
   on client.clientno=viewing.clientno))tab
   on client.clientno=tab.clientno;


   
--3. Create a stored procedure name sp_disp_staff_position where the procedure should display 
--the fname and salary for all the staff whose position value substitute at runtime. 
  select * from staff;
  create procedure sp_disp_staff_position(@position varchar(20)) as
  select fname,salary 
  from staff
  where oposition=@position; 

  exec sp_disp_staff_position 'assistant';



--4. Create a stored procedure that should display owner fname, address and telephoneno, property type,
-- rent for all the ownerno which is supplied at runtime
  select * from propertyforrent;
   select * from privateowner;
   select * from viewing;
   create procedure pro4 (@own varchar(10)) as
   select fname,address,telno,propertytype,rent
   from privateowner join propertyforrent
   on privateowner.ownerno=propertyforrent.ownerno
   where privateowner.ownerno=@own;
   exec pro4 'CO40';




--5. Create a stored procedure that should accept property type as parameter and it should display how many properties available in the given type.
--The output should display like
--The Total number of Flat [Flat is a property type] available is 6.
--If the given property not exist then it should display like
--No such property type exist.

   alter procedure pr5(@protype varchar(10)) as
   if(@protype=(select distinct propertytype from propertyforrent where propertytype=@protype))
   begin
   declare @pname varchar(20)
   declare @count int
   select @pname=propertytype,@count=count(propertytype) 
   from propertyforrent
   where propertytype=@protype
   group by propertytype
   print 'The Total number of '  +@pname+'availabe is '  +cast(@count as varchar(10))
   end
   else
   begin
   print 'No such property exist'
   end
   exec pr5 'hoe';
    


--6. Create a stored procedure that should accept branch no as parameter and display the city details in the form of output parameter.
--The output should like below format:
--The City is London
   select * from branch;
   ALTER procedure pro6(@brno varchar(10)) as
   declare @city varchar(20)
   select @city=city 
   from branch
   where branchno=@brno
   print 'The city is ' +@city;

   exec pro6 'B002';

--7. Create a stored procedure that will calculate the average of given two numbers at run time.
--You have to accept two input parameters and one output parameter for display the average as output.
--This procedure will pass these two input information to another procedure which will calculate the total 
--and pass the total as output parameter.
--Procedure 1: val1, val2, average output
--Procedure 2: val1, val2, total output
--The output should be like below 
--The average is: 5
     
ALTER procedure stored_ww(@i1 int,@i2 int) as
declare @tot int;
declare @avg numeric(10,5);
exec stored_ww2 @i1,@i2,@tot out;
set @avg=(@tot/2);
print'The average is: '+convert(varchar(20),@avg);

alter procedure stored_ww2(@ii1 int,@ii2 int,@ires int out) as
set @ires=@ii1+@ii2;

exec stored_ww 5,7 

--***************************************STORED PROCEDURE************************************************
create procedure pr1 as
select * from branch;

exec pr1;


create procedure pr2 (@sno varchar(20)) as
select * from staff
where staffno=@sno;

exec pr2 'SG14';

create procedure pr3(@prno varchar(20),@city varchar(20) out,@rent decimal(5,1) out) as
select @city=city,@rent=rent from propertyforrent where propertyno=@prno;

select * from propertyforrent;

declare @gg varchar(20)
declare @kk decimal(5,1)
exec pr3 'PA14',@gg out,@kk out
if @gg is null 
print 'Property no is invalid'
else
print @gg+convert(varchar(20),@kk);


select * from branch;
delete from branch where branchno='B010';

create procedure disp_branch_bno(@bno varchar(20)) as
select street,city,postcode from branch
where branchno=@bno; 
 
exec disp_branch_bno 'B002';

create procedure disp_staff_branch(@brno varchar(20),@countval int out) as
select @countval=count(staffno) 
from staff 
where branchno=@brno
group by branchno;

declare @d int;
exec disp_staff_branch 'B003',@d out;
print convert(varchar(20),@d);

select * from staff;

delete from branch where branchno='B119';

Create table tblStudents

(

 Id int identity primary key,

 Name nvarchar(50),

 TotalMarks int

)

 select * from tblStudents;

Insert into tblStudents values ('Mark', 900)

Insert into tblStudents values ('Pam', 760)

Insert into tblStudents values ('John', 980)

Insert into tblStudents values ('Ram', 990)

Insert into tblStudents values ('Ron', 440)

Insert into tblStudents values ('Able', 320)

Insert into tblStudents values ('Steve', 983)

Insert into tblStudents values ('James', 720)

Insert into tblStudents values ('Mary', 870)

Insert into tblStudents values ('Nick', 680)