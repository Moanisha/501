create database hotel;

create table hotel(
hotelno varchar(10),
hotelname varchar(20),
city varchar(20),
primary key (hotelno)
);

create table room(
roomno numeric(5),
hotelno varchar(10),
type varchar(10),
price decimal(5,2),
primary key (roomno, hotelno),
foreign key (hotelno) REFERENCES hotel(hotelno)
);


create table guest(
guestno numeric(5),
guestname varchar(20),
guestaddress varchar(50),
primary key (guestno)
);

create table booking(
hotelno varchar(10),
guestno numeric(5),
datefrom date,
dateto date,
roomno numeric(5),
primary key (hotelno, guestno, datefrom),
foreign key (roomno, hotelno) REFERENCES room(roomno, hotelno),
foreign key (guestno) REFERENCES guest(guestno)
);


insert into hotel values('ch01','Omni Shoreham','London');
insert into hotel values('ch02','Phoenix Park','London');
insert into hotel values('dc01','Latham','Berlin');
insert into hotel values('fb01','Grosvenor','London');
insert into hotel values('fb02','Watergate','Paris');


insert into room values(501,'fb01','single',19.00);
insert into room values(601,'fb01','double',29.00);
insert into room values(701,'ch02','single',10.00);
insert into room values(701,'fb01','family',39.00);
insert into room values(801,'ch02','double',15.00);
insert into room values(901,'dc01','single',18.00);
insert into room values(1001,'ch01','single',29.99);
insert into room values(1001,'dc01','double',30.00);
insert into room values(1001,'fb02','single',58.00);
insert into room values(1101,'ch01','family',59.99);
insert into room values(1101,'dc01','family',35.00);
insert into room values(1101,'fb02','double',86.00);



insert into guest values(10001,'John Kay','56 High St, London');
insert into guest values(10002,'Mike Ritchie','18 Tain St, London');
insert into guest values(10003,'Mary Tregear','5 Tarbot Rd, Aberdeen');
insert into guest values(10004,'Joe Keogh','2 Fergus Dr, Aberdeen');
insert into guest values(10005,'Carol Farrel','6 Achray St, Glasgow');
insert into guest values(10006,'Tina Murphy','63 Well St, Glasgow');
insert into guest values(10007,'Tony Shaw','12 Park Pl, Glasgow');



insert into booking values('ch01',10006,'2004-04-21',NULL,1101);
insert into booking values('ch02',10002,'2004-04-25','2004-05-06',801);
insert into booking values('dc01',10003,'2004-05-20',NULL,1001);
insert into booking values('dc01',10007,'2004-05-13','2004-05-15',1001);
insert into booking values('fb01',10001,'2004-04-01','2004-04-08',501);
insert into booking values('fb01',10001,'2004-05-01',NULL,701);
insert into booking values('fb01',10002,'2016-05-04','2004-05-29',601);
insert into booking values('fb01',10004,'2004-04-15','2004-05-15',601);
insert into booking values('fb01',10005,'2004-05-02','2004-05-07',501);
insert into booking values('fb02',10003,'2004-04-05','2010-04-04',1001);
insert into booking values('fb02',10005,'2004-05-12','2030-05-04',1101);

select * from guest;
select * from room;
select * from hotel;
select * from booking;


--1. List full details of all hotels.
     select * from hotel;

--2. List full details of all hotels in London. 
     select * from hotel where city='London';

--3. List the names and addresses of all guests in London, alphabetically ordered by name. 
     select guestname,guestaddress 
	 from guest where guestaddress like '%London%'
	 order by guestname;
	 
--4. List all double or family rooms with a price below �40.00 per night, in ascending order of price
     select * from room 
	 where price < 40.00 and (type='single' or type='double')
	 order by price; 

--5. List the bookings for which no dateTo has been specified.
     select * from booking where dateto is null;
     
--6. How many hotels are there? 
     select count(hotelno) from hotel;  

--7. What is the average price of a room?
     select avg(price) from room;
     
--8. What is the total revenue for all double rooms?
     select sum(price) from room where type='double';

--9. How many different guests have made bookings for April month only?
     select count(guestno) from booking where datefrom between '2004-04-01' and '2004-04-30';
	  
--10. List the price and type of all rooms at the Grosvenor Hotel. 
      select price,type from room join hotel 
	  on room.hotelno=hotel.hotelno
	  where hotelname='Grosvenor';

--11. List all guests currently staying at the Grosvenor Hotel.
      select * from guest where guestno in(
	  select distinct booking.guestno from hotel join booking 
	  on booking.hotelno=hotel.hotelno
	  where hotelname='Grosvenor');

--12. List the details of all rooms at the Grosvenor Hotel, 
--including the name of the guest staying in the room, if the room is occupied. 
     select room.roomno,room.hotelno,type,price,guestname from room join booking on
	 room.roomno=booking.roomno join guest on 
	 booking.guestno=guest.guestno
     where room.hotelno =(select hotelno from hotel where hotelname='Grosvenor'); 
	 
--13. List the number of rooms in each hotel. 
      select hotelno,count(roomno) from room 
	  group by hotelno;

--14. List the number of rooms in each hotel in London.
      select hotelno,count(roomno) from room
	  where hotelno in(select hotelno from hotel where city='London') 
	  group by hotelno;

       
