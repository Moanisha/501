CREATE TABLE [dbo].[info](
[remarks] [varchar](50) NULL
) ON [PRIMARY]
 
INSERT [dbo].[info] ([remarks]) VALUES (N'ActionScript')
INSERT [dbo].[info] ([remarks]) VALUES (N'Boostrap')
INSERT [dbo].[info] ([remarks]) VALUES (N'C')
INSERT [dbo].[info] ([remarks]) VALUES (N'C++')
INSERT [dbo].[info] ([remarks]) VALUES (N'Ecommerce')
INSERT [dbo].[info] ([remarks]) VALUES (N'Jquery')
INSERT [dbo].[info] ([remarks]) VALUES (N'Groovy')
INSERT [dbo].[info] ([remarks]) VALUES (N'Java')
INSERT [dbo].[info] ([remarks]) VALUES (N'JavaScript')
INSERT [dbo].[info] ([remarks]) VALUES (N'Lua')
INSERT [dbo].[info] ([remarks]) VALUES (N'Perl')
INSERT [dbo].[info] ([remarks]) VALUES (N'Ruby')
INSERT [dbo].[info] ([remarks]) VALUES (N'Scala')
INSERT [dbo].[info] ([remarks]) VALUES (N'Swing')
INSERT [dbo].[info] ([remarks]) VALUES (N'XHTML')

select * from info;