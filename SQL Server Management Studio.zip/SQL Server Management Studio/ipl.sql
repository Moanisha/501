           create database ipl;

create table Venue(
                venue_id int,
                venueName varchar(20),
				CityName varchar(20),
				constraint venue_pk primary key(venue_id)
                );

alter table Venue alter column venueName varchar(200);
insert into Venue values(1,'M Chinnaswamy Stadium','Bangalore');
insert into Venue values(2,'Punjab Cricket Association Stadium, Mohali','Chandigarh');
insert into Venue values(3,'Feroz Shah Kotla','Delhi');
insert into Venue values(4,'Wankhede Stadium','Mumbai');
insert into Venue values(5,'Eden Gardens','Kolkata');
insert into Venue values(6,'Sawai Mansingh Stadium','Jaipur');
insert into Venue values(7,'Rajiv Gandhi International Stadium, Uppal','Hyderabad');
insert into Venue values(8,'MA Chidambaram Stadium, Chepauk','Chennai');







create table Team(
                team_id int,
                teamName varchar(20) not null,
                constraint team_pk primary key(team_id)
                );
alter table Team alter column teamName varchar(50);

insert into Team values(1,'Kolkata Knight Riders');
insert into Team values(2,'Chennai Super Kings');
insert into Team values(3,'Rajasthan Royals');
insert into Team values(4,'Mumbai Indians');
insert into Team values(5,'Deccan Chargers');
insert into Team values(6,'Kings XI Punjab');
insert into Team values(7,'Royal Challengers Bangalore');
insert into Team values(8,'Delhi Daredevils');

delete from Team where team_id=20;    
select * from Team;            
create table Umpire(
                umpire_id int,
                umpireName varchar(20) not null,
                constraint umpire_pk primary key(umpire_id)
                );
 alter table Umpire alter column umpireName varchar(80);               

 insert into Umpire values(1,'Asad Rauf');
 insert into Umpire values(2,'RE Koertzen');
 insert into Umpire values(3,'MR Benson');               
 insert into Umpire values(4,'SL Shastri');               
 insert into Umpire values(5,'Aleem Dar');               
 insert into Umpire values(6,'GA Pratapkumar');               
 insert into Umpire values(7,'SJ Davis');               
 insert into Umpire values(8,'DJ Harper');
 insert into Umpire values(9,'BF Bowden');
 insert into Umpire values(10,'K Hariharan');
 insert into Umpire values(11,'RB Tiffin');
 insert into Umpire values(12,'IL Howell');
 insert into Umpire values(13,'AM Saheba');
               
select * from Venue;
select * from Umpire;
select * from Team;                
create table Match_Details(
                match_no int,
                team_id1 int not null,
				team_id2 int not null,
				umpire1 int not null,
				umpire2 int not null,
				venue int not null,
                mDate Date not null,
                season varchar(20) not null, 
                constraint mdetails_pk primary key(match_no),
				constraint tid1_fk foreign key(team_id1) references Team(team_id),
				constraint tid2_fk foreign key(team_id2) references Team(team_id),
				constraint ump1_fk foreign key(umpire1) references Umpire(umpire_id),
				constraint ump2_fk foreign key(umpire1) references Umpire(umpire_id),
				constraint venue_fk foreign key(venue) references Venue(venue_id)
                );

insert into Match_Details values(1,1,7,1,2,1,'2008-04-18','2008');
insert into Match_Details values(2,2,6,3,4,2,'2008-04-19','2008');
insert into Match_Details values(3,3,8,5,6,3,'2008-04-19','2008');
insert into Match_Details values(4,4,7,7,8,4,'2008-04-20','2008');
insert into Match_Details values(5,5,1,9,10,5,'2008-04-20','2008');
insert into Match_Details values(6,6,3,5,11,6,'2008-04-21','2008');
insert into Match_Details values(7,5,8,12,13,7,'2008-04-22','2008');
insert into Match_Details values(8,2,4,8,6,8,'2008-04-23','2008');
insert into Match_Details values(9,5,3,1,3,7,'2008-04-24','2008');
insert into Match_Details values(10,6,4,5,13,2,'2008-04-25','2008');
insert into Match_Details values(11,7,3,3,12,1,'2008-04-26','2008');


                
create table match_Results(
                match_no int,
                tossWinner int not null,
                tossDecision varchar(20) not null,
                resultType varchar(20) not null,
                dlApplied binary not null,
                winner int,
                winByRuns int,
                winByWickets int,
                PlayerOfMatch varchar(20),
				constraint results_pk primary key(match_no),
				constraint matchno_fk foreign key(match_no) references Match_Details(match_no),
				constraint tosswin_fk foreign key(tossWinner) references Team(team_id),
				constraint winner_fk foreign key(winner) references Team(team_id)
				);

insert into match_Results values(1,7,'field','normal',0,1,140,0,'BB McCullum');
insert into match_Results values(2,2,'bat','normal',0,2,33,0,'MEK Hussey');
insert into match_Results values(3,3,'bat','normal',0,8,0,9,'MF Maharoof');
insert into match_Results values(4,4,'bat','normal',0,7,0,5,'MV Boucher');
insert into match_Results values(5,5,'bat','normal',0,1,0,5,'DJ Hussey');
insert into match_Results values(6,6,'bat','normal',0,3,0,6,'SR Watson');
insert into match_Results values(7,5,'bat','normal',0,8,0,9,'V Sehwag');
insert into match_Results values(8,4,'field','normal',0,2,6,0,'ML Hayden');                
insert into match_Results values(9,3,'field','normal',0,3,0,3,'YK Pathan');
insert into match_Results values(10,4,'field','normal',0,6,66,0,'KC Sangakkara');
insert into match_Results values(11,3,'field','normal',0,3,0,7,'SR Watson');

select * from match_Results;

select * from Match_Details;
delete from Match_Details where match_no=15;
select match_no from Match_Details
order by match_no;

select teamName from Team join Match_Details
on Team.team_id=Match_Details.team_id1
where match_no=5;

select umpireName from Umpire join Match_Details on Umpire.umpire_id=Match_Details.umpire1;

select venueName from Venue join Match_Details on venue.venue_id=Match_Details.venue;


create table users_db(
username varchar(50),
pwd varchar(30)
constraint login_pk primary key(username)
);


insert into users_db values('Moanisha','aaa');

select * from users_db;

delete from users_db where username='';
select tab1.match_no,tab1.teamName as tosswinner,tab1.tossDecision,tab1.resultType,tab2.teamName as winner,tab1.winByRuns,tab1.winByWickets,tab1.PlayerOfMatch
from
(select match_no,teamName,tossDecision,resultType,winByRuns,winByWickets,PlayerOfMatch
from match_Results join Team
on match_Results.tossWinner=Team.team_id)tab1
join
(select match_no,teamName
from match_Results join Team
on match_Results.winner=Team.team_id)tab2
on
tab1.match_no=tab2.match_no;