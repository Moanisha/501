﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using data_access;

namespace ClassLibrary1
{
    public class blp
    {
        public string createnewbranch()
        {
            Class1 da = new Class1();
            string d=da.getmax();
            string ed = null;
            int h = int.Parse(d.Substring(1, 3));
            h++;
            if (h < 10)
            {
                ed = d.Substring(0, 3);
            }

            if (h >= 10 && h <= 99)
            {
                ed = d.Substring(0, 2);
            }
            if (h >= 100)
            {
                ed = d.Substring(0, 1);
            }

            d = string.Join("", ed, (h.ToString()));
            return d; 
        }
        public string insertbranch(string bid, string st, string cit, string po)
        {
            Class1 da = new Class1();
            int a=da.insertbranch(bid, st, cit, po);
            if (a > 0)
                return "Records inserted";
            else
                return "Insertion failed";

        }
    }
}
