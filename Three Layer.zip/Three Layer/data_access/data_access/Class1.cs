﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace data_access
{
    public class Class1
    {
        public string getmax()
        {
            string constring = "server=pc251449;database=Task1;integrated security=false;User Id=sa;password=password-1";
            string qry = "select max(branchno) from branch";
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand cmd = new SqlCommand(qry, con);
            string s = (string)cmd.ExecuteScalar();
            return s;
        }
        public int insertbranch(string bid, string st, string cit, string po)
        {
            string constring = "server=pc251449;database=Task1;integrated security=false;User Id=sa;password=password-1";
            string qry = "insert into branch values(@a,@b,@c,@d)";
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = qry;
            SqlParameter p1 = cmd.Parameters.Add("@a", SqlDbType.VarChar, 20);
            p1.Value = bid;
            SqlParameter p2 = cmd.Parameters.Add("@b", SqlDbType.VarChar, 20);
            p2.Value = st;
            SqlParameter p3 = cmd.Parameters.Add("@c", SqlDbType.VarChar, 20);
            p3.Value = cit;
            SqlParameter p4 = cmd.Parameters.Add("@d", SqlDbType.VarChar, 20);
            p4.Value = po;
            return cmd.ExecuteNonQuery();



        }
    }
}
