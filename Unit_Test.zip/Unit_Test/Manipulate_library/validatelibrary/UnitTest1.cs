﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Manipulate_library;
using System.Collections.Generic;

namespace validatelibrary
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            manipulate m = new manipulate();   //Arrange
            int result = m.addition(5, 2);     //Act
            Assert.AreEqual(7, result);        //Assert
        }
        [TestMethod]
        public void TestMethod2()
        {
            manipulate m = new manipulate();
            bool res = m.showres();
            Assert.AreEqual(true, res);
        }

        //Test collections
        [TestMethod]
        public void TestMethod3()
        {
            //List<string> l1 = new List<string>();
            //l1.Add("A");
            //List<string> l2 = new List<string>();
            //l2.Add("B");
            //CollectionAssert.AreEqual(l1, l2);
            List<string> l3 = new List<string>();
            l3.Add("Moanisha");
            l3.Add("Kiran");
            l3.Add("Sruthi");
            //CollectionAssert.AllItemsAreUnique(l3);
            //CollectionAssert.Contains(l3, "Sruthi");
            CollectionAssert.AllItemsAreNotNull(l3);
        }

    }
}
