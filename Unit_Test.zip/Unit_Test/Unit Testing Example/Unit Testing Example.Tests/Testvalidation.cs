﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Unit_Testing_Example.Controllers;
using System.Web.Mvc;

namespace Unit_Testing_Example.Tests
{
    [TestClass]
    public class Testvalidation
    {
        [TestMethod]
        public void TestMethod1()
        {
            StuController sc = new StuController();
            var res = sc.changedata(1) as ViewResult;
            Assert.AreEqual("BE", res.ViewName);
        }
    }
}
