﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Unit_Testing_Example.Controllers
{
    public class StuController : Controller
    {
        //
        // GET: /Stu/

        public ActionResult changedata(int type)
        {
            if (type == 1)
                return View("BE");
            else if (type == 2)
                return View("MBA");
            else
                return Content("Not a valid Choice");
        }

    }
}
