﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using carRegistrationDataAccesslayer;

namespace carRegistrationBusinessLogic
{
    public class carRentalBusinessLogic
    {
        carRegistrationDatalayer carRegister = new carRegistrationDatalayer();
        /// <summary>
        /// To get the list of brand names from the data access layer
        /// </summary>
        /// <returns>List of brand names(string)</returns>
        public List<string> generatingCarBrandName()
        {
            List<string> brandName = carRegister.populatingCarBrandName();
            return brandName;
        }
        /// <summary>
        /// To get the list of type of cars from the data access layer for the corresponding brandname(parameter)
        /// </summary>
        /// <param name="brandName">Brandname of car</param>
        /// <returns>List of type of cars(string)</returns>
        public List<string> generatingCarTypeName(string brandName)
        {
            List<string> typename = carRegister.populatingCarTypeName(brandName);
                return typename;
        }
        /// <summary>
        /// It will pass the entered customer details to the dataaccess layer to insert into CustomerRegistrationDetails table
        /// </summary>
        /// <param name="detail">Contains all the fields of CustomerRegistrationDetails table</param>
        /// <returns>Success or Error message(string)</returns>
        public string saveRentalValues(customerRegistrationDetail customerDetail)
        {
            int result = carRegister.insertingCustomerDetails(customerDetail.customerName,customerDetail.emailId,customerDetail.phoneNumber,customerDetail.carBrand,customerDetail.carType,customerDetail.carPrice);
            if (result == 1)
            {
                return "Success";
            }
            else
            {
                return "Error";
            }
        }
      
    }
}
