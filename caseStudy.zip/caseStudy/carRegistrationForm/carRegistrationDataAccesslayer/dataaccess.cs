﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace carRegistrationDataAccesslayer
{
    public class carRegistrationDatalayer
    {
       
        CarRentalDataBaseEntities2 carRental = new CarRentalDataBaseEntities2();
     /// <summary>
     /// To insert customer details into CarRegistration Database
     /// </summary>
     /// <param name="detail">Contains all the fields of CustomerRegistrationDetails table</param>
     /// <returns>Number of rows inserted(int)</returns>
        public int insertingCustomerDetails(string customerName,string emailId,long phoneNumber,string carBrand,string carType,string carPrice)
        {
            int insertCount = carRental.insertCustomerDetails(customerName,emailId,phoneNumber,carBrand,carType,carPrice);
            return insertCount;
        }
       /// <summary>
       /// To get the available brand names from the CarDetails table 
       /// </summary>
       /// <returns>List of Car Brandnames(string)</returns>
        public List<string> populatingCarBrandName()
        {
            List<string> carBrandNames = carRental.populatingCarBrandNames().ToList();
            return carBrandNames;
        }
       /// <summary>
       /// To get the available type of cars for the selected brand name from CarDetails table
       /// </summary>
       /// <param name="carBrand">Contains the Brand of the car</param>
       /// <returns>List of type of cars(string)</returns>
        public List<string> populatingCarTypeName(string carBrand)
        {
            List<string> carTypeNames = carRental.populatingCarTypeNames(carBrand).ToList();
            return carTypeNames;
        }
    }
}
