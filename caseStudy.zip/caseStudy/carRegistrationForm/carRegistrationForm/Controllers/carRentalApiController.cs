﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using carRegistrationBusinessLogic;
using carRegistrationDataAccesslayer;

namespace carRegistrationForm.Controllers
{
    public class carRentalApiController : ApiController
    {
        carRentalBusinessLogic carRental = new carRentalBusinessLogic();
        /// <summary>
        /// To get the list of brand names available from the business logic
        /// </summary>
        /// <returns>List of brand names of car(string)</returns>
        [HttpGet]
        public List<string> populatingcarBrandName()
        {
            List<string> brandName = carRental.generatingCarBrandName();
            return brandName;
        }
        /// <summary>
        /// To get the type of cars for a corresponding brandname(parameter) from business logic
        /// </summary>
        /// <param name="brandListValue">Brandname of car</param>
        /// <returns>List of type of cars(string)</returns>
        [HttpGet]
        public List<string> populatingcarTypeName(string brandListValue)
        {
            List<string> brandType = carRental.generatingCarTypeName(brandListValue);
            return brandType;
        }
        /// <summary>
        /// Save the customer details into the CustomerRegistrationDetails table
        /// </summary>
        /// <param name="detail">Contails all the fields of CustomerRegistrationDetails table</param>
        /// <returns>Status message(string)</returns>
        [HttpPost]
        public string saveCarRegisterValues(customerRegistrationDetail customerDetail)
        {
            string insertResult = carRental.saveRentalValues(customerDetail);
            return insertResult;
        }
    }
}
