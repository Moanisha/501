﻿
//Form Validation and Ajax Calling Webservice

$(document).ready(function () {
//Calling a webservice using ajax to get the value for brandname dropdownlist
    $.ajax({
        url: "/api/carRentalApi/populatingcarBrandName",
        type: "GET",
        dataType: "json",
        contentType: "application/json;charset=UTF-8",
        success: function (data) {
            $.each(data, function (key, val) {
                $("#brandList").append("<option class='dropdown-content'>" + val + "</option>");
               
            })
        },
        error: function (xhr) {               
        },
        statusCode:
            {
                404: function () {
                    alert("No records found to display");
                }
            }
    });


//Bootstrap Validation for form fields
    $('#contact_form').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {

//To check whether the entered data is a valid email address
            email: {
                validators: { notEmpty: { message: 'Enter email id' }, emailAddress: { message: 'Email ID not valid' } }
            },

//To check whether the entered data is a valid phone number
            phone: {
                validators: { notEmpty: { message: 'Enter the phone number' }, phone: { country: 'IND', message: 'Enter a valid 10 digit number' } }
            }

        }
    });


//Calling a webservice using ajax to get the value for type of car dropdownlist for corresponding brand name data
    $("#brandList").change(function () {
        var res = $(this).val();
        $.ajax({
            url: "/api/carRentalApi/populatingcarTypeName",
            type: "GET",
            dataType: "json",
            data: { 'brandListValue': res },
            contentType: "application/json;charset=UTF-8",
            success: function (data) {
                $("#typeList").empty();
                $("#typeList").append("<option>TYPE OF CAR</option>");
                $.each(data, function (key, val) {
                    $("#typeList").append("<option>" + val + "</option>");
                })
            },
            error: function (xhr) {
            },
            statusCode:
                {
                    404: function () {
                        alert("No records found to display");
                    }
                }
        });

    });


//Send button click validation functions using Toasters
    $("#sendDetails").click(function () {
        
//Name textbox empty validation check
        if ($("#fullNametxt").val() === "") {
            $.toaster({ priority: 'danger', title: 'Alert : ', message: 'Please Enter your Name' });
        }
//Email textbox empty validation check
        else if ($("#Emailtxt").val() === "") {

            $.toaster({ priority: 'danger', title: 'Alert : ', message: 'Please Enter Email ID' });
        }

//Phone number textbox empty validation check
        else if ($("#phonetxt").val() === "") {

            $.toaster({ priority: 'danger', title: 'Alert : ', message: 'Please Enter Phone no' });
        }

//Check if Brandname dropdownlist is selected
        else if ($("#brandList").val() === "SELECT BRAND") {

            $.toaster({ priority: 'danger', title: 'Alert : ', message: 'Please choose Brand of Car' });
        }

//Check if Type of car dropdownlist is selected
        else if ($("#typeList").val() === "TYPE OF CAR") {

            $.toaster({ priority: 'danger', title: 'Alert : ', message: 'Please choose Type of Car' });
        }

//Check if Price Range radio button is selected
        else if (!$("input[name=price]:checked").val()) {

            $.toaster({ priority: 'danger', title: 'Alert : ', message: 'Please select Price Range' });
        }


//Sending all the form field values to webservice 
        else {

            var registerDetails = {};
            registerDetails.customerName = $("#fullNametxt").val();
            registerDetails.emailId = $("#Emailtxt").val();
            registerDetails.phoneNumber = $("#phonetxt").val();
            registerDetails.carBrand = $("#brandList").val();
            registerDetails.carType = $("#typeList").val();
            registerDetails.carPrice = $("input[name=price]:checked").val();
            var res = JSON.stringify(registerDetails);
            $.ajax({
                url: "/api/carRentalApi/saveCarRegisterValues",
                type: "POST",
                dataType: "json",
                data: res,
                contentType: "application/json;charset=UTF-8",
                success: function (data) {
                      $.toaster({ priority: 'success', title: 'Alert : ', message: 'Registration success' });
                                     setTimeout(function () {
                        window.location.reload();
                    },2500);
                },
                error: function (xhr) {
                    $.toaster({ priority: 'danger', title: 'Alert : ', message: 'Error occured' });
                },

            });
        }
        });
    
    });
    
