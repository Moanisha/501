﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using TMU.DataAccess;

namespace TMU.BusinessRules
{
    public class TMU_BusinessRules
    {
        public DataTable FetchDatatable()
        {
            try
            {
                TMU_DataAccess EmployeeData = new TMU_DataAccess();
                DataTable EmployeeDataTable = EmployeeData.CreateDatatable();
                return EmployeeDataTable;
            }
            catch (Exception)
            {
                throw new Exception();
            } 
        }
    }
}
