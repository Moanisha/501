﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace TMU.DataAccess
{
    public class TMU_DataAccess
    {
        public DataTable CreateDatatable()
        {
            try
            {
                DataTable EmployeeDatatable = new DataTable();
                EmployeeDatatable.Clear();
                EmployeeDatatable.Columns.Add("Employee_ID");
                EmployeeDatatable.Columns.Add("Name");
                EmployeeDatatable.Columns.Add("Gender");
                EmployeeDatatable.Columns.Add("Age");
                EmployeeDatatable.Rows.Add(621859, "Ravi", "Male", 25);
                EmployeeDatatable.Rows.Add(621639, "Rajesh", "Male", 23);
                EmployeeDatatable.Rows.Add(621755, "Sruthi", "Female", 22);
                return EmployeeDatatable;
            }
            catch (Exception)
            {
                throw new Exception();
            } 
        }
    }
}
