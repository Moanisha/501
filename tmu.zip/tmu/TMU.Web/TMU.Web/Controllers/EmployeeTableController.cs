﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using TMU.Web.Models;
using TMU.BusinessRules;
using System.Data;

namespace TMU.Web.Controllers
{
    public class EmployeeTableController : ApiController
    {
        TMU_BusinessRules EmployeeDataObject = new TMU_BusinessRules();

        [HttpGet]
        public List<EmployeeData> PopulateTable()
        {
            try
            {
                List<EmployeeData> EmployeeData = new List<EmployeeData>();
                foreach (DataRow item in EmployeeDataObject.FetchDatatable().Rows)
                {
                    EmployeeData Data = new EmployeeData();
                    Data.Employee_ID = Convert.ToInt32(item[0]);
                    Data.Name = (string)item[1];
                    Data.Gender = (string)item[2];
                    Data.Age = Convert.ToInt32(item[3]);
                    EmployeeData.Add(Data);
                }
                return EmployeeData;
            }
            catch (Exception)
            {
                return new List<EmployeeData>() {};
            }
        }
    }
}