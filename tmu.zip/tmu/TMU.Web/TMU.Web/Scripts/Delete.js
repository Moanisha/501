﻿
$(document).ready(function () {
    $('#delete').prop("disabled", true);
    var table = $('#data').DataTable();

    $('#data tbody').on('click', 'tr', function () {
        if ($(this).hasClass('selected')) {
            $(this).removeClass('selected');
            $('#delete').prop("disabled", true);
        }
        else {
            table.$('tr.selected').removeClass('selected');
            $(this).addClass('selected');
            $('#delete').prop("disabled", false);
        }
    });


    $('#delete').click(function () {
       
            $.confirm({
                title: 'Confirm Delete',

                buttons: {
                    confirm: function () {
                        table.row('.selected').remove().draw(false);
                    },
                    cancel: function () {
                        $.alert('Canceled!');
                    }
                }
            })
       
    });
        
    });
