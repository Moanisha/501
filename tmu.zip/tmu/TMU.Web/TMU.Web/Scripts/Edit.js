﻿$(document).ready(function () {

    $('#data').Tabledit({
   
        columns: {
       
            identifier: [0, 'Employee_ID'],                   
            editable: [[1, 'Name'], [2, 'Gender'],[3,'Age']]
      
        },
        buttons: {

        }
    })
});
